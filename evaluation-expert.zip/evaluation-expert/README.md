# 评估专家 (Evaluation Expert) 技能包

数字员工评估系统，用于评估其他数字员工的工作表现。

## 架构概览

```
┌─────────────────────────────────────────────────────────────┐
│  用户沙箱 (User's Sandbox)                                     │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  live_evaluation_coordinator (评估入口)              │   │
│  │    ├─> Python CLI (数据采集)                         │   │
│  │    ├─> evaluator (评分逻辑)                          │   │
│  │    └─> training_advisor (改进建议)                   │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                          │
                          │ WebSocket 连接
                          ▼
┌─────────────────────────────────────────────────────────────┐
│  目标员工沙箱 (Target Employee Sandbox)                        │
│  - 被评估的数字员工正在运行                                     │
└─────────────────────────────────────────────────────────────┘
```

## 目录结构

```
skills/evaluation-expert/
├── README.md (本文件)
│
├── live_evaluation_coordinator/
│   └── SKILL.md                    # 评估流程入口和协调器
│
├── live_evaluator/
│   ├── SKILL.md                    # 数据采集 Skill 定义
│   ├── evaluate.py                 # Python CLI 主入口
│   ├── ws_client.py                # WebSocket 连接模块
│   ├── http_client.py              # HTTP API 补充采集
│   ├── trace_builder.py            # 执行过程格式化
│   ├── requirements.txt            # Python 依赖
│   ├── README.md                   # Python 工具使用说明
│   ├── .gitignore
│   └── test_cases/
│       ├── connectivity_test.json  # 连通性测试用例
│       └── customer_service_demo.json  # 客服场景测试用例
│
├── evaluator/
│   └── SKILL.md                    # 评估打分 Skill
│
├── report_generator/
│   └── SKILL.md                    # HTML 报告生成 Skill
│
├── training_advisor/
│   └── SKILL.md                    # 训练建议 Skill
│
├── evaluation_orchestrator/
│   └── SKILL.md                    # 完整评估流程编排器（未来使用）
│
└── scenario_parser/
    └── SKILL.md                    # 场景解析 Skill
```

## 快速开始

### 1. 准备环境

确保 Python 环境已安装依赖：

```bash
cd skills/evaluation-expert/live_evaluator
pip install -r requirements.txt
```

### 2. 启动评估

在对话中与评估协调器 Skill 交互：

```
用户: 评估客服专员

Skill: 好的，我来帮你评估客服专员的表现。
      请提供目标员工沙箱的 Gateway 地址：
      格式: HOST:PORT 或 ws://HOST:PORT/path/ws

用户: ws://183.6.65.92:90/xxx/18789/ws

Skill: 收到。请提供用于连接的 JWT Token：

用户: eyJhbGc...

[后续流程自动进行...]
```

### 3. 查看评估报告

评估完成后，Skill 会输出：
- 综合评分
- 各维度得分
- 关键问题列表
- 改进建议
- 原始数据文件路径

## 核心组件

### 1. live_evaluation_coordinator (评估协调器)

**职责**：
- 评估流程入口
- 渐进式收集用户输入（endpoint, token, 测试用例）
- 测试连通性
- 调用 Python CLI 采集数据
- 调用 evaluator Skill 评分
- 输出评估报告

**特点**：
- ✅ 轻量级编排，不包含业务逻辑
- ✅ 渐进式披露，用户体验友好
- ✅ 复用已有 Skills，避免重复开发

### 2. live_evaluator (数据采集工具)

**职责**：
- 连接目标员工沙箱 WebSocket
- 发送测试消息
- 采集执行过程（对话、工具调用、思考链路）
- 格式化为 `execution_trace` 结构

**技术栈**：
- Python 3.10+
- websockets 库
- 异步 I/O

**输出格式**：
```json
{
  "meta": {...},
  "test_cases": [...],
  "turns": [
    {
      "turn_index": 0,
      "test_case_id": "TC-001",
      "user_input": "...",
      "execution_trace": {
        "logs": [...],
        "raw_messages": [...],
        "think_blocks": [...],
        "summary": {...}
      }
    }
  ]
}
```

### 3. evaluator (评估打分 Skill)

**职责**：
- 根据 execution_trace 进行多维度评分
- 应用评分规则
- 生成问题列表和改进建议

**评估维度**：
1. 功能完整性 (functional_completeness)
2. 交互质量 (interaction_quality)
3. 流程合规 (process_compliance)
4. 问题解决 (problem_resolution)
5. 工具调用正确性 (tool_call_correctness)

**合格标准**：
- 综合评分 ≥ 70 分
- 各维度得分 ≥ 60 分
- 工具调用正确性 ≠ 0（无严重违规）

### 4. report_generator (报告生成 Skill)

**职责**：
- 将 trace_result.json 转换为可视化 HTML 评估报告
- 应用 evaluator 评分规则进行多维度打分
- 生成美观的报告页面（含雷达图、时间线等）

**特点**：
- ✅ 完整的 HTML 报告（6 个区块）
- ✅ Chart.js 雷达图可视化
- ✅ 时间线/思考链路/工具调用/回复内容四个 Tab
- ✅ 改进建议和表现亮点列表
- ✅ 分数等级颜色区分

**输出位置**：
```
默认: docs/evaluation_report_{timestamp}.html
```

**使用方式**：
```
用户: /tmp/trace_result.json 生成评估报告

Skill: 📋 正在生成评估报告...
      ✅ 报告已生成！
      文件路径: docs/evaluation_report.html
```

### 5. training_advisor (训练建议 Skill)

**职责**：
- 根据评估结果生成改进方案
- 提供具体的训练建议
- 生成配置修改建议

## 使用场景

### 场景 1：评估新上岗的数字员工

```
目的: 验证新员工是否达到上岗标准
流程:
  1. 准备标准测试用例
  2. 运行评估
  3. 查看评估报告
  4. 根据改进建议调整配置
  5. 重新评估直到合格
```

### 场景 2：定期质量检查

```
目的: 监控在岗员工的服务质量
流程:
  1. 使用真实用户场景作为测试用例
  2. 定期运行评估
  3. 对比历史评估结果
  4. 发现质量下降趋势
  5. 及时调整和优化
```

### 场景 3：A/B 测试不同配置

```
目的: 对比不同配置的效果
流程:
  1. 准备相同的测试用例
  2. 评估配置 A
  3. 评估配置 B
  4. 对比评分和问题列表
  5. 选择最优配置
```

## 测试用例格式

测试用例使用 JSON 格式定义：

```json
{
  "test_cases": [
    {
      "test_case_id": "TC-001",
      "scenario_name": "场景名称",
      "input": {
        "user_request": "用户输入的消息",
        "context": {
          "order_id": "ORD-123",
          "product_name": "商品名称"
        }
      },
      "expected_behavior_sequence": [
        {
          "step": 1,
          "action": "预期行为描述",
          "criteria": "评判标准"
        }
      ],
      "expected_output": {
        "resolution": "预期解决结果",
        "user_satisfaction": "用户满意度",
        "artifacts_created": ["工单", "记录"]
      }
    }
  ]
}
```

## 评估报告示例

```markdown
# 📋 评估报告

## 基本信息
- 目标员工: 客服专员
- 评估时间: 2026-04-24 11:30:00
- 测试用例数: 2
- 总执行时长: 24.57s

## 综合评分
**总分: 85/100** ✅ 合格

| 维度 | 得分 | 状态 |
|------|------|------|
| 功能完整性 | 90 | ✅ 优秀 |
| 交互质量 | 85 | ✅ 良好 |
| 流程合规 | 80 | ✅ 良好 |
| 问题解决 | 88 | ✅ 优秀 |
| 工具调用正确性 | 0 | ❌ 严重问题 |

## ⚠️ 关键问题
1. 未调用工单创建工具
2. 缺少同理心表达

## 💡 改进建议
1. [严重] 必须调用 create_ticket 工具
2. [高] 增加同理心表达
3. [中] 主动确认用户满意度
```

## 常见问题

### Q1: 如何获取目标员工的 endpoint 和 token？

**A**: 
- endpoint: 从沙箱管理 API 获取 `gateway_endpoint`
- token: 使用你自己的 JWT token（需要有访问目标沙箱的权限）

### Q2: 测试用例应该包含多少个场景？

**A**: 建议 3-5 个典型场景，覆盖：
- 正常流程
- 异常处理
- 边界情况

### Q3: 评估需要多长时间？

**A**: 取决于测试用例数量和每个场景的复杂度：
- 单个场景: 10-30 秒
- 3-5 个场景: 1-3 分钟

### Q4: 如何查看详细的执行过程？

**A**: 查看生成的 JSON 文件：
- `/tmp/trace_result.json` - 完整的执行过程
- `/tmp/evaluation_result.json` - 评估详情

### Q5: 可以评估哪些类型的数字员工？

**A**: 任何基于 OpenClaw Gateway 的数字员工，包括：
- 客服专员
- 销售顾问
- 技术支持
- 内容审核员
- 等等

## 开发指南

### 添加新的评估维度

1. 在 `evaluator/SKILL.md` 中定义新维度
2. 添加评分规则
3. 更新权重配置

### 自定义测试用例

1. 创建 JSON 文件
2. 定义场景和预期行为
3. 在评估时上传或指定文件路径

### 扩展数据采集

1. 修改 `trace_builder.py` 添加新的数据提取逻辑
2. 更新输出格式
3. 确保 evaluator Skill 能够处理新数据

## 未来规划

- [ ] 支持批量评估多个员工
- [ ] 历史评估记录和趋势分析
- [ ] 可视化评估报告
- [ ] 自动生成测试用例
- [ ] 评估模板库（不同岗位）
- [ ] 实时监控和告警

## 贡献

欢迎提交 Issue 和 Pull Request！

## 许可证

[待定]
