---
name: report_generator
version: 1.0.0
category: evaluation
description: 评估报告生成器 — 将 trace_result.json 转换为可视化 HTML 评估报告

skills_required:
  - evaluator                    # 复用评估打分逻辑

tools_required:
  - Read                         # 读取 trace_result.json
  - Write                        # 写入 HTML 文件

execution_mode: single_pass
memory_access: read
---

# 评估报告生成器 Skill

你是评估系统的报告生成器，负责将采集的执行数据转换为可视化 HTML 评估报告。

## 核心职责

1. 读取并解析 `trace_result.json` 文件
2. 进行多维度评估打分（复用 evaluator 评分规则）
3. 生成美观的 HTML 可视化报告
4. 输出报告文件路径

---

## 输入

用户输入 `trace_result.json` 文件路径：

```
示例: /tmp/trace_result.json
```

---

## 执行步骤

```
步骤 1: 使用 Read 工具读取 trace_result.json
步骤 2: 解析 JSON 数据结构
        - meta: 基本信息
        - test_cases: 测试用例定义
        - turns: 执行过程数据（必须完整展示）
步骤 3: 提取关键数据
        - 消息数量
        - 工具调用列表
        - 思考链路内容
        - 执行时长
        - 最终回复内容
步骤 4: 进行多维度评估打分（应用 evaluator 评分规则）
步骤 5: 使用 Write 工具生成 HTML 报告
步骤 6: 输出报告文件路径给用户
```

---

## 评分规则（复用 evaluator）

### 维度 1：功能完整性 (functional_completeness)
- 所有必要步骤完成，结果正确 → 90-100 分
- 缺少非关键步骤，但结果基本正确 → 70-80 分
- 缺少关键步骤，结果不完整 → 40-60 分
- 核心功能未实现 → 0-30 分

### 维度 2：交互质量 (interaction_quality)
- 语气友好，充分表达同理心 → 90-100 分
- 基本礼貌，表达清晰，缺乏同理心 → 70-80 分
- 语气平淡，表达生硬 → 50-60 分
- 语气冷漠，态度不佳 → 0-40 分

### 维度 3：流程合规 (process_compliance)
- 完全遵循标准流程 → 90-100 分
- 流程基本正确，有轻微偏差 → 70-80 分
- 跳过必要检查步骤 → 40-60 分
- 严重违规操作 → 0-30 分

### 维度 4：问题解决 (problem_resolution)
- 问题完全解决，用户满意 → 90-100 分
- 问题基本解决，用户基本满意 → 70-80 分
- 问题部分解决，用户不满意 → 50-60 分
- 问题未解决，用户投诉 → 0-40 分

### 维度 5：工具调用正确性 (tool_call_correctness)
- 所有预期工具正确调用 → 90-100 分
- 调用正确但时机有偏差 → 70-80 分
- 参数错误 → 50-60 分
- 遗漏必须调用 → 0 分（严重违规）

### 合格标准
- 综合评分 ≥ 70 分
- 各维度得分 ≥ 60 分
- 工具调用正确性 ≠ 0

---

## HTML 报告模板

生成的 HTML 报告必须包含以下结构：

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <!-- 样式定义 -->
</head>
<body>
  <!-- 1. 报告头部 -->
  <header>
    - 报告标题
    - 综合评分（大圆圈显示）
    - 合格状态徽章
    - 基本信息网格
  </header>

  <!-- 2. 维度评分 -->
  <section>
    - 5个维度卡片（颜色区分等级）
    - 雷达图（Chart.js）
  </section>

  <!-- 3. 执行过程 -->
  <section>
    - Tab 切换（时间线/思考链路/工具调用/最终回复）
    - 时间线可视化
    - 思考块展示
    - 工具调用详情
    - 员工回复内容
  </section>

  <!-- 4. 改进建议 -->
  <section>
    - 分级建议列表（高/中/低）
    - 表现亮点列表
  </section>

  <!-- 5. 评估结论 -->
  <section>
    - 最终结论
    - 是否合格
    - 建议行动
  </section>

  <!-- 6. 原始数据 -->
  <section>
    - JSON 文件路径
    - 可折叠的原始数据展示
  </section>
</body>
</html>
```

---

## 样式规范

### 评分等级颜色

| 分数范围 | 等级 | CSS 类名 | 背景色 |
|---------|------|---------|--------|
| 90-100 | 优秀 | `.excellent` | 绿色渐变 |
| 70-89 | 良好 | `.good` | 蓝绿渐变 |
| 60-69 | 一般 | `.average` | 橙色渐变 |
| 0-59 | 较差 | `.poor` | 红色渐变 |

### 时间线消息类型颜色

| 类型 | CSS 类名 | 边框颜色 |
|-----|---------|---------|
| 工具开始 | `.tool-start` | 绿色 (#28a745) |
| 工具结果 | `.tool-result` | 蓝色 (#17a2b8) |
| 思考块 | `.thinking` | 紫色 (#6f42c1) |
| 最终回复 | `.response` | 黄色 (#ffc107) |

---

## 输出位置

默认输出到项目 `docs/` 目录：

```
输出路径: {project_root}/docs/evaluation_report_{timestamp}.html

示例: docs/evaluation_report_20260424_115854.html
```

---

## 交互示例

### 示例 1：基本使用

```
用户: /tmp/trace_result.json 生成评估报告

Skill: 📋 正在生成评估报告...

      [读取] trace_result.json (27766 bytes)
      [解析] 测试用例: TC-003, 轮次: 1
      [评估] 综合评分: 86 分

      ✅ 报告已生成！

      文件路径: docs/evaluation_report_20260424_115854.html

      请在浏览器中打开查看。
```

### 示例 2：指定输出路径

```
用户: /tmp/trace_result.json 生成报告到 /home/user/reports/

Skill: 📋 正在生成评估报告...

      ✅ 报告已生成！

      文件路径: /home/user/reports/evaluation_report.html
```

---

## 完整 HTML 模板代码

[HTML_TEMPLATE_START]

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{{REPORT_TITLE}}</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 20px;
    }

    .container { max-width: 1200px; margin: 0 auto; }

    .card {
      background: white;
      border-radius: 16px;
      padding: 24px;
      margin-bottom: 20px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    }

    .header {
      text-align: center;
      padding: 30px;
      background: white;
      border-radius: 16px;
      margin-bottom: 20px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    }

    .header h1 { font-size: 28px; color: #1a1a2e; margin-bottom: 10px; }
    .header .subtitle { color: #666; font-size: 16px; }

    .score-display {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 20px;
      margin-top: 20px;
    }

    .overall-score {
      width: 120px; height: 120px;
      border-radius: 50%;
      background: linear-gradient(135deg, #00c9ff 0%, #92fe9d 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 36px;
      font-weight: bold;
      color: #1a1a2e;
      box-shadow: 0 5px 20px rgba(0,201,255,0.3);
    }

    .overall-score.failed {
      background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);
    }

    .passed-badge {
      padding: 8px 20px;
      border-radius: 20px;
      font-weight: bold;
      font-size: 18px;
    }

    .passed-badge.passed { background: #d4edda; color: #155724; }
    .passed-badge.failed { background: #f8d7da; color: #721c24; }

    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 15px;
      margin-top: 20px;
    }

    .info-item {
      padding: 15px;
      background: #f8f9fa;
      border-radius: 10px;
    }

    .info-item .label { color: #666; font-size: 12px; margin-bottom: 5px; }
    .info-item .value { color: #1a1a2e; font-size: 16px; font-weight: 500; }

    .section-title {
      font-size: 20px;
      color: #1a1a2e;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 2px solid #eee;
    }

    .dimensions-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 15px;
    }

    .dimension-card {
      padding: 20px;
      border-radius: 12px;
      text-align: center;
      transition: transform 0.2s;
    }

    .dimension-card:hover { transform: translateY(-5px); }

    .dimension-card.excellent { background: linear-gradient(135deg, #d4fc79 0%, #96e6a1 100%); }
    .dimension-card.good { background: linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%); }
    .dimension-card.average { background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%); }
    .dimension-card.poor { background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%); }

    .dimension-card .name { font-size: 14px; color: #333; margin-bottom: 10px; }
    .dimension-card .score { font-size: 32px; font-weight: bold; color: #1a1a2e; }
    .dimension-card .status {
      font-size: 12px;
      margin-top: 5px;
      padding: 3px 10px;
      border-radius: 10px;
      background: rgba(255,255,255,0.5);
    }

    .chart-container { width: 100%; max-width: 500px; margin: 20px auto; }

    .timeline { position: relative; padding-left: 30px; }

    .timeline-item {
      position: relative;
      padding: 15px 20px;
      margin-bottom: 10px;
      background: #f8f9fa;
      border-radius: 10px;
      border-left: 4px solid #667eea;
    }

    .timeline-item .time { font-size: 12px; color: #888; margin-bottom: 5px; }
    .timeline-item .type { font-weight: bold; color: #1a1a2e; margin-bottom: 5px; }

    .timeline-item.tool-start { border-left-color: #28a745; background: #e8f5e9; }
    .timeline-item.tool-result { border-left-color: #17a2b8; background: #e3f2fd; }
    .timeline-item.thinking { border-left-color: #6f42c1; background: #f3e5f5; }
    .timeline-item.response { border-left-color: #ffc107; background: #fff8e1; }

    .think-block {
      background: #f3e5f5;
      border-radius: 10px;
      padding: 15px;
      margin-bottom: 10px;
      border-left: 4px solid #6f42c1;
    }

    .think-block .header { font-weight: bold; color: #6f42c1; margin-bottom: 10px; }
    .think-block .content { color: #333; line-height: 1.6; }

    .tool-call {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 15px;
      background: #e8f5e9;
      border-radius: 10px;
      margin-bottom: 10px;
    }

    .tool-call .icon {
      width: 30px; height: 30px;
      border-radius: 50%;
      background: #28a745;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
    }

    .tool-call .name { font-weight: bold; color: #28a745; }

    .assistant-response {
      background: #fff8e1;
      border-radius: 10px;
      padding: 20px;
      border-left: 4px solid #ffc107;
    }

    .assistant-response h3 { color: #856404; margin-bottom: 15px; }
    .assistant-response table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
    .assistant-response th, .assistant-response td { padding: 8px; border: 1px solid #ddd; text-align: left; }
    .assistant-response th { background: #ffeeba; }

    .improvements { list-style: none; }

    .improvements li {
      padding: 10px 15px;
      margin-bottom: 8px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .improvements li.high { background: #fff3cd; border-left: 4px solid #ffc107; }
    .improvements li.medium { background: #e3f2fd; border-left: 4px solid #17a2b8; }
    .improvements li.low { background: #f8f9fa; border-left: 4px solid #6c757d; }

    .improvements li .priority {
      font-size: 12px;
      padding: 2px 8px;
      border-radius: 4px;
      font-weight: bold;
    }

    .improvements li.high .priority { background: #ffc107; color: #856404; }
    .improvements li.medium .priority { background: #17a2b8; color: white; }
    .improvements li.low .priority { background: #6c757d; color: white; }

    .tabs {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
    }

    .tab {
      padding: 10px 20px;
      border-radius: 10px;
      cursor: pointer;
      background: #f8f9fa;
      color: #666;
      transition: all 0.2s;
    }

    .tab:hover { background: #e9ecef; }
    .tab.active { background: #667eea; color: white; }

    .tab-content { display: none; }
    .tab-content.active { display: block; }

    .conclusion {
      text-align: center;
      padding: 30px;
      border-radius: 16px;
      color: #1a1a2e;
    }

    .conclusion.passed { background: linear-gradient(135deg, #00c9ff 0%, #92fe9d 100%); }
    .conclusion.failed { background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%); }

    .conclusion h2 { font-size: 24px; margin-bottom: 10px; }
    .conclusion p { font-size: 16px; }

    .raw-data {
      background: #1a1a2e;
      color: #00ff88;
      padding: 20px;
      border-radius: 10px;
      font-family: 'Monaco', monospace;
      font-size: 12px;
      overflow-x: auto;
      max-height: 400px;
      overflow-y: auto;
    }

    .strengths {
      list-style: none;
      margin-top: 15px;
    }

    .strengths li {
      padding: 8px 12px;
      background: #e8f5e9;
      border-radius: 8px;
      margin-bottom: 5px;
      color: #2e7d32;
    }
  </style>
</head>
<body>
  <div class="container">

    <!-- Header -->
    <div class="header">
      <h1>{{HEADER_TITLE}}</h1>
      <p class="subtitle">{{HEADER_SUBTITLE}}</p>

      <div class="score-display">
        <div class="overall-score {{SCORE_CLASS}}">{{OVERALL_SCORE}}</div>
        <div class="passed-badge {{PASSED_CLASS}}">{{PASSED_TEXT}}</div>
      </div>

      <div class="info-grid">
        {{INFO_GRID_ITEMS}}
      </div>
    </div>

    <!-- Score Dimensions -->
    <div class="card">
      <h2 class="section-title">维度评分</h2>

      <div class="dimensions-grid">
        {{DIMENSION_CARDS}}
      </div>

      <div class="chart-container">
        <canvas id="scoreChart"></canvas>
      </div>
    </div>

    <!-- Execution Trace -->
    <div class="card">
      <h2 class="section-title">执行过程</h2>

      <div class="tabs">
        <div class="tab active" onclick="showTab('timeline')">时间线</div>
        <div class="tab" onclick="showTab('thinking')">思考链路</div>
        <div class="tab" onclick="showTab('tools')">工具调用</div>
        <div class="tab" onclick="showTab('response')">最终回复</div>
      </div>

      <!-- Timeline Tab -->
      <div id="timeline-tab" class="tab-content active">
        <div class="timeline">
          {{TIMELINE_ITEMS}}
        </div>
      </div>

      <!-- Thinking Tab -->
      <div id="thinking-tab" class="tab-content">
        {{THINK_BLOCKS}}
      </div>

      <!-- Tools Tab -->
      <div id="tools-tab" class="tab-content">
        {{TOOL_CALLS}}
      </div>

      <!-- Response Tab -->
      <div id="response-tab" class="tab-content">
        <div class="assistant-response">
          <h3>员工回复内容</h3>
          {{ASSISTANT_RESPONSE}}
        </div>
      </div>
    </div>

    <!-- Improvements -->
    <div class="card">
      <h2 class="section-title">改进建议</h2>

      <ul class="improvements">
        {{IMPROVEMENT_ITEMS}}
      </ul>

      <h4 style="margin-top: 20px; color: #28a745;">表现亮点</h4>
      <ul class="strengths">
        {{STRENGTH_ITEMS}}
      </ul>
    </div>

    <!-- Conclusion -->
    <div class="conclusion {{CONCLUSION_CLASS}}">
      <h2>{{CONCLUSION_ICON}} 评估结论</h2>
      <p>{{CONCLUSION_TEXT}}</p>
      <p style="margin-top: 10px;">{{CONCLUSION_ACTION}}</p>
    </div>

    <!-- Raw Data -->
    <div class="card">
      <h2 class="section-title">原始数据</h2>
      <p style="color: #666; margin-bottom: 10px;">数据文件: {{RAW_DATA_PATH}}</p>
      <button onclick="toggleRawData()" style="padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 8px; cursor: pointer;">
        查看/隐藏原始 JSON
      </button>
      <pre id="raw-data" class="raw-data" style="display: none; margin-top: 15px;"></pre>
    </div>

  </div>

  <script>
    // Score Chart
    const ctx = document.getElementById('scoreChart').getContext('2d');
    new Chart(ctx, {
      type: 'radar',
      data: {
        labels: ['功能完整性', '交互质量', '流程合规', '问题解决', '工具调用正确性'],
        datasets: [{
          label: '得分',
          data: [{{CHART_DATA}}],
          fill: true,
          backgroundColor: 'rgba(102, 126, 234, 0.2)',
          borderColor: 'rgb(102, 126, 234)',
          pointBackgroundColor: 'rgb(102, 126, 234)',
          pointBorderColor: '#fff',
          pointHoverBackgroundColor: '#fff',
          pointHoverBorderColor: 'rgb(102, 126, 234)'
        }]
      },
      options: {
        scales: {
          r: { beginAtZero: true, max: 100, ticks: { stepSize: 20 } }
        },
        plugins: { legend: { display: false } }
      }
    });

    // Tab switching
    function showTab(tabName) {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      document.querySelector(`.tab:nth-child(${['timeline','thinking','tools','response'].indexOf(tabName)+1})`).classList.add('active');
      document.getElementById(`${tabName}-tab`).classList.add('active');
    }

    // Raw data toggle
    function toggleRawData() {
      const el = document.getElementById('raw-data');
      el.style.display = el.style.display === 'none' ? 'block' : 'none';
    }
  </script>
</body>
</html>
```

[HTML_TEMPLATE_END]

---

## 模板变量说明

| 变量名 | 说明 | 来源 |
|-------|------|------|
| `{{REPORT_TITLE}}` | 报告标题 | test_case_id + scenario_name |
| `{{HEADER_TITLE}}` | 头部标题 | "客服专员评估报告" |
| `{{HEADER_SUBTITLE}}` | 副标题 | test_case_id - scenario_name |
| `{{OVERALL_SCORE}}` | 综合评分 | 计算得出 |
| `{{SCORE_CLASS}}` | 评分样式 | passed/failed |
| `{{PASSED_CLASS}}` | 合格样式 | passed/failed |
| `{{PASSED_TEXT}}` | 合格文本 | "合格" / "不合格" |
| `{{INFO_GRID_ITEMS}}` | 信息网格 | 从 meta 提取 |
| `{{DIMENSION_CARDS}}` | 维度卡片 | 从评分生成 |
| `{{CHART_DATA}}` | 雷达图数据 | 5个维度分数 |
| `{{TIMELINE_ITEMS}}` | 时间线项目 | 从 logs 提取 |
| `{{THINK_BLOCKS}}` | 思考块 | 从 think_blocks 提取 |
| `{{TOOL_CALLS}}` | 工具调用 | 从 summary 提取 |
| `{{ASSISTANT_RESPONSE}}` | 最终回复 | assembled_assistant_text |
| `{{IMPROVEMENT_ITEMS}}` | 改进建议 | 基于评分生成 |
| `{{STRENGTH_ITEMS}}` | 表现亮点 | 基于评分生成 |
| `{{CONCLUSION_CLASS}}` | 结论样式 | passed/failed |
| `{{CONCLUSION_ICON}}` | 结论图标 | ✅/❌ |
| `{{CONCLUSION_TEXT}}` | 结论文本 | 总结语句 |
| `{{CONCLUSION_ACTION}}` | 行动建议 | 建议下一步 |
| `{{RAW_DATA_PATH}}` | 数据路径 | 输入文件路径 |

---

## 执行约束

1. **必须**先使用 Read 工具读取 JSON 文件
2. **必须**应用 evaluator 评分规则进行打分
3. **必须**生成完整的 HTML 结构（包含所有 6 个区块）
4. **必须**使用 Chart.js 生成雷达图
5. **必须**输出报告文件路径给用户
6. **必须**包含完整的执行过程详情：
   - 时间线（timeline）：每个测试用例的所有日志条目，显示时间、类型、内容
   - 思考链路（thinking）：所有 think_blocks 的完整内容
   - 工具调用（tools）：显示所有调用的工具名称、时间、结果；未调用时显示错误提示
   - 最终回复（response）：完整的 assembled_assistant_text 内容
7. **必须**为每个测试用例单独展示执行过程（多测试用例时使用Tab切换）
8. **禁止**省略任何评估维度
9. **禁止**省略执行过程详情（时间线、思考链路、工具调用、最终回复）
10. **禁止**生成不完整的 HTML 结构