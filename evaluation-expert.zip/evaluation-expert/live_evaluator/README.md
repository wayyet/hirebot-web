# live_evaluator — 实时评估数据采集工具

连接已运行的数字员工沙箱，采集 execution_trace，供 `evaluator` Skill 使用。

## 环境准备

```bash
cd skills/evaluation-expert/live_evaluator

# 创建虚拟环境
python -m venv .venv

# 激活（Linux/macOS）
source .venv/bin/activate

# 激活（Windows PowerShell）
.venv\Scripts\Activate.ps1

# 安装依赖
pip install -r requirements.txt
```

## 使用

```bash
python evaluate.py \
  --endpoint <HOST:PORT> \
  --token <JWT_TOKEN> \
  --test-cases test_cases/customer_service_demo.json \
  --output trace_result.json
```

### 参数说明

| 参数 | 说明 | 必填 |
|------|------|------|
| `--endpoint` | Gateway 地址，格式 `HOST:PORT`，例：`localhost:18789` | ✅ |
| `--token` | JWT Bearer Token | ✅ |
| `--test-cases` | 测试用例 JSON 文件路径 | ✅ |
| `--output` | 输出文件路径（默认 `trace_result.json`） | ❌ |
| `--timeout` | 每轮等待超时秒数（默认 60） | ❌ |
| `--no-http-supplement` | 跳过 HTTP API 补充采集 | ❌ |

## 测试用例格式

参考 `test_cases/customer_service_demo.json`，补充你自己的场景：

```json
{
  "test_cases": [
    {
      "test_case_id": "TC-001",
      "scenario_name": "场景名称",
      "input": {
        "user_request": "发给客服员工的消息"
      },
      "expected_behavior_sequence": [...],
      "expected_output": {...}
    }
  ]
}
```

## 输出

`trace_result.json` 结构：

```
meta          — 采集元信息（endpoint、时间、轮次数）
test_cases    — 原始测试用例
turns[]       — 每轮对话
  ├── user_input
  └── execution_trace
        ├── logs[]         — 格式化消息（thought/tool_call/assistant_message/...）
        ├── raw_messages[] — 完整原始 WS 消息（不丢弃）
        └── summary        — 统计摘要
http_supplement — HTTP API 补充数据（runtime-events/sessions 等）
```

## 模块说明

| 文件 | 职责 |
|------|------|
| `evaluate.py` | CLI 主入口，串联各模块 |
| `ws_client.py` | WebSocket 连接 + 消息采集（原子） |
| `http_client.py` | HTTP API 补充采集（原子，可单独运行） |
| `trace_builder.py` | 格式化 execution_trace（原子） |
