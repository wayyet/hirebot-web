"""
ws_client.py — WebSocket 连接 + 消息采集（原子模块）

职责：
  - 连接目标员工沙箱 WebSocket
  - 发送用户消息
  - 收集所有服务端推送消息，原样保存
  - 等待 assistant_done 信号后返回本轮完整消息列表

不做任何评估逻辑，不解析消息语义。

endpoint 格式（任意一种均可）：
  - HOST:PORT                              → 自动补 ws:// 和 /ws
  - ws://HOST:PORT/path/to/ws             → 直接使用，追加 token
  - http://HOST:PORT/path                 → 替换为 ws://，追加 /ws + token
"""

import asyncio
import json
import re
import time
from datetime import datetime, timezone
from typing import Any

import websockets
from websockets.exceptions import ConnectionClosed


def build_ws_url(endpoint: str, token: str) -> str:
    """
    对齐前端 gateway-ws.ts 的 buildGatewayWsUrl 逻辑。

    支持：
      - 裸 HOST:PORT          → ws://HOST:PORT/ws?token=...
      - http(s)://...         → ws(s)://...[/ws]?token=...
      - ws(s)://...           → 直接使用，追加 token
    """
    base = endpoint.strip()

    # http/https → ws/wss
    if re.match(r'^https?://', base, re.IGNORECASE):
        base = re.sub(r'^http', 'ws', base, flags=re.IGNORECASE)
    elif not re.match(r'^wss?://', base, re.IGNORECASE):
        # 裸 HOST:PORT，补协议
        base = f"ws://{base.lstrip('/')}"

    # 去掉已有的 token 参数（避免重复）
    base = re.sub(r'([?&])token=[^&]*(&)?', r'\1', base)
    base = base.rstrip('?&')

    # 如果路径里没有 /ws，追加
    if not re.search(r'/ws($|[?#])', base, re.IGNORECASE):
        base = base.rstrip('/') + '/ws'

    sep = '&' if '?' in base else '?'
    return f"{base}{sep}token={token}"


class WsCollector:
    """
    连接单个 Gateway WebSocket，采集消息。

    用法：
        async with WsCollector(endpoint, token) as collector:
            messages = await collector.send_and_collect("用户消息")
    """

    def __init__(self, endpoint: str, token: str, timeout: int = 60):
        """
        Args:
            endpoint: Gateway 地址（支持多种格式，见模块说明）
            token:    JWT Bearer Token
            timeout:  等待 assistant_done 的超时秒数
        """
        self.endpoint = endpoint
        self.token = token
        self.timeout = timeout
        self._ws = None

    @property
    def ws_url(self) -> str:
        return build_ws_url(self.endpoint, self.token)

    async def __aenter__(self):
        url = self.ws_url
        print(f"[WS] 连接: {url}")
        self._ws = await websockets.connect(
            url,
            ping_interval=20,
            ping_timeout=10,
            open_timeout=15,
            additional_headers={},   # 不传 Authorization header，token 在 URL query 里
        )
        print(f"[WS] 已连接")
        return self

    async def __aexit__(self, *args):
        if self._ws:
            await self._ws.close()

    async def send_and_collect(self, user_text: str) -> list[dict[str, Any]]:
        """
        发送一条用户消息，收集直到 assistant_done 的所有服务端消息。

        Returns:
            原始消息列表，每条附加 _received_at 时间戳字段
        """
        payload = json.dumps({"type": "user_message", "text": user_text})
        await self._ws.send(payload)

        collected: list[dict[str, Any]] = []
        deadline = time.monotonic() + self.timeout

        while time.monotonic() < deadline:
            try:
                remaining = deadline - time.monotonic()
                raw = await asyncio.wait_for(self._ws.recv(), timeout=remaining)
            except asyncio.TimeoutError:
                break
            except ConnectionClosed:
                break

            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                msg = {"_raw": raw}

            msg["_received_at"] = datetime.now(timezone.utc).isoformat()
            collected.append(msg)

            if msg.get("type") == "assistant_done":
                break

        return collected

    async def approve_tool(self, call_id: str, approved: bool = True) -> None:
        """审批工具调用（如果 approval_required 出现时使用）。"""
        payload = json.dumps({
            "type": "approve_tool",
            "callId": call_id,
            "approved": approved,
        })
        await self._ws.send(payload)
