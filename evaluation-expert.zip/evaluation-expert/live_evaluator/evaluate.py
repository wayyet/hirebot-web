"""
evaluate.py — 主入口 CLI

用法：
    python evaluate.py \
        --endpoint localhost:18789 \
        --token <JWT> \
        --test-cases test_cases/customer_service_demo.json \
        --output trace_result.json

输出 trace_result.json 供 evaluation_orchestrator / evaluator Skill 使用。
"""

import argparse
import asyncio
import json
import sys
from pathlib import Path

from ws_client import WsCollector
from http_client import HttpCollector
from trace_builder import build_turn_trace, build_trace_result


def load_test_cases(path: str) -> list[dict]:
    """加载测试用例 JSON 文件。"""
    p = Path(path)
    if not p.exists():
        print(f"[ERROR] 测试用例文件不存在: {path}", file=sys.stderr)
        sys.exit(1)
    with open(p, encoding="utf-8") as f:
        data = json.load(f)
    # 支持两种格式：直接列表 或 {"test_cases": [...]}
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and "test_cases" in data:
        return data["test_cases"]
    print(f"[ERROR] 测试用例格式不正确，期望列表或 {{\"test_cases\": [...]}}", file=sys.stderr)
    sys.exit(1)


async def run(
    endpoint: str,
    token: str,
    test_cases: list[dict],
    test_case_file: str,
    output: str,
    timeout: int,
    http_supplement: bool,
) -> None:
    turns = []

    async with WsCollector(endpoint, token, timeout=timeout) as collector:
        for i, tc in enumerate(test_cases):
            tc_id = tc.get("test_case_id", f"TC-{i+1:03d}")
            user_input = tc.get("input", {}).get("user_request", "")

            if not user_input:
                print(f"[WARN] 测试用例 {tc_id} 缺少 input.user_request，跳过", file=sys.stderr)
                continue

            print(f"[{i+1}/{len(test_cases)}] 发送测试消息: {tc_id}")
            print(f"  → {user_input}")

            raw_messages = await collector.send_and_collect(user_input)
            print(f"  ← 收到 {len(raw_messages)} 条消息")

            # 自动审批工具调用（如果有 approval_required）
            for msg in raw_messages:
                if msg.get("type") == "approval_required":
                    call_id = msg.get("callId")
                    tool_name = msg.get("toolName", "unknown")
                    print(f"  [审批] 自动批准工具调用: {tool_name} (callId={call_id})")
                    await collector.approve_tool(call_id, approved=True)

            turn = build_turn_trace(
                turn_index=i,
                test_case_id=tc_id,
                user_input=user_input,
                raw_messages=raw_messages,
            )
            turns.append(turn)

            summary = turn["execution_trace"]["summary"]
            print(f"  工具调用: {summary['tool_calls_list']}")
            print(f"  有思考链路: {summary['has_thought']} (共 {summary['think_count']} 块)")
            if summary['think_count'] > 0:
                print(f"  思考内容预览:")
                for idx, think in enumerate(turn["execution_trace"]["think_blocks"][:2], 1):
                    preview = think[:100] + "..." if len(think) > 100 else think
                    print(f"    [{idx}] {preview}")
            print(f"  执行时长: {summary['execution_time_seconds']}s")
            print()

    # HTTP 补充采集
    supplement = None
    if http_supplement:
        print("[HTTP] 补充采集运行时数据...")
        supplement = HttpCollector(endpoint, token).collect_all()
        print(f"[HTTP] 完成")

    result = build_trace_result(
        endpoint=endpoint,
        test_case_file=test_case_file,
        test_cases=test_cases,
        turns=turns,
        http_supplement=supplement,
    )

    with open(output, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"\n[完成] trace_result 已写入: {output}")
    print(f"  总轮次: {len(turns)}")
    print(f"  文件大小: {Path(output).stat().st_size} bytes")


def main():
    parser = argparse.ArgumentParser(
        description="评估员工数据采集工具 — 连接数字员工沙箱，采集 execution_trace"
    )
    parser.add_argument(
        "--endpoint", required=True,
        help="目标员工沙箱 Gateway 地址，格式 HOST:PORT（例：localhost:18789）"
    )
    parser.add_argument(
        "--token", required=True,
        help="JWT Bearer Token"
    )
    parser.add_argument(
        "--test-cases", required=True,
        help="测试用例 JSON 文件路径"
    )
    parser.add_argument(
        "--output", default="trace_result.json",
        help="输出文件路径（默认：trace_result.json）"
    )
    parser.add_argument(
        "--timeout", type=int, default=60,
        help="每轮等待 assistant_done 的超时秒数（默认：60）"
    )
    parser.add_argument(
        "--no-http-supplement", action="store_true",
        help="跳过 HTTP API 补充采集"
    )

    args = parser.parse_args()

    from ws_client import build_ws_url
    test_cases = load_test_cases(args.test_cases)
    print(f"[加载] 测试用例: {len(test_cases)} 条，来自 {args.test_cases}")
    print(f"[连接] endpoint: {args.endpoint}")
    print(f"[连接] WS URL:   {build_ws_url(args.endpoint, args.token[:20] + '...')}")
    print()

    asyncio.run(run(
        endpoint=args.endpoint,
        token=args.token,
        test_cases=test_cases,
        test_case_file=args.test_cases,
        output=args.output,
        timeout=args.timeout,
        http_supplement=not args.no_http_supplement,
    ))


if __name__ == "__main__":
    main()
