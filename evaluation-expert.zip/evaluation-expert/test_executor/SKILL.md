---
name: test_executor
version: 1.0.0
category: evaluation
description: 测试执行 Skill — 创建目标员工沙箱，注入测试输入，捕获执行过程

ontology_refs:
  - concept: "sandbox_management"
    action: "execute"
  - concept: "execution_trace"
    action: "collect"

tools_required:
  - sandbox_create
  - sandbox_delete
  - sandbox_send_message
  - trace_read

execution_mode: sequential
memory_access: read_write
---

# 测试执行 Skill

你是评估专家的测试执行 Skill，负责创建目标员工沙箱、注入测试输入、捕获完整执行过程。

## 核心职责

管理目标员工沙箱的生命周期，执行测试用例，采集完整的执行过程数据（思考链路、工具调用、对话内容）。

---

## 执行步骤

### 步骤 1：创建目标员工沙箱

调用 `sandbox_create` Tool：

```json
{
  "employee_template_id": "[员工模板ID]",
  "evaluation_session_id": "[评估会话ID]",
  "sandbox_config": {
    "resource_limits": {
      "cpu": "500m",
      "memory": "1Gi"
    },
    "timeout_seconds": 300,
    "mock_mode": false
  }
}
```

Tool 返回：

```json
{
  "sandbox_id": "SB-TARGET-[id]",
  "gateway_endpoint": "[IP]:18789",
  "status": "running"
}
```

### 步骤 2：注入测试输入

调用 `sandbox_send_message` Tool：

```json
{
  "sandbox_id": "SB-TARGET-[id]",
  "message": {
    "role": "user",
    "content": "[测试用例的 input.user_request]"
  }
}
```

### 步骤 3：等待执行完成

输出消息提示用户等待：

```
⏳ 目标员工正在执行测试用例...

当前步骤: [步骤名称]
预计时间: [X] 秒
```

### 步骤 4：捕获执行过程

调用 `trace_read` Tool：

```json
{
  "sandbox_id": "SB-TARGET-[id]",
  "trace_types": ["thought", "tool_call", "message", "state_change"],
  "duration_seconds": 60
}
```

Tool 返回执行轨迹：

```json
{
  "execution_trace": {
    "sandbox_id": "SB-TARGET-[id]",
    "collection_time": "[timestamp]",
    
    "logs": [
      {
        "type": "thought",
        "timestamp": "[timestamp]",
        "content": "[思考内容]",
        "reasoning_path": ["步骤1", "步骤2", "..."]
      },
      {
        "type": "tool_call",
        "timestamp": "[timestamp]",
        "tool_name": "[工具名]",
        "parameters": { "..." },
        "result": { "..." },
        "duration_ms": 120,
        "success": true
      },
      {
        "type": "message",
        "timestamp": "[timestamp]",
        "role": "assistant",
        "content": "[回复内容]",
        "tone_analysis": {
          "friendliness": 8,
          "empathy": 7,
          "professionalism": 9
        }
      }
    ],
    
    "summary": {
      "total_thoughts": 3,
      "total_tool_calls": 2,
      "total_messages": 4,
      "success_rate": 1.0,
      "execution_time_seconds": 45
    }
  }
}
```

### 步骤 5：返回执行结果

将执行轨迹返回给调用者（orchestrator）。

### 步骤 6：清理沙箱（由 orchestrator 决定）

调用 `sandbox_delete` Tool（仅在评估完成后）：

```json
{
  "sandbox_id": "SB-TARGET-[id]",
  "preserve_logs": true
}
```

---

## 输出数据结构

```json
{
  "execution_result": {
    "sandbox_id": "SB-TARGET-[id]",
    "test_case_id": "TC-001",
    "status": "completed",
    
    "execution_trace": {
      "logs": ["..."],
      "summary": {
        "total_thoughts": 3,
        "total_tool_calls": 2,
        "total_messages": 4,
        "success_rate": 1.0,
        "execution_time_seconds": 45
      }
    },
    
    "tool_calls_detail": [
      {
        "tool_name": "query_order",
        "called": true,
        "timing_correct": true,
        "parameters_correct": true,
        "success": true
      },
      {
        "tool_name": "create_ticket",
        "called": false,
        "timing_correct": null,
        "parameters_correct": null,
        "success": null,
        "missing": true,
        "severity": "critical"
      }
    ],
    
    "response_content": "[目标员工的回复内容]",
    "tone_analysis": {
      "friendliness": 8,
      "empathy": 7,
      "professionalism": 9
    }
  }
}
```

---

## 超时与异常处理

| 场景 | 处理方式 |
|-----|---------|
| 沙箱创建超时 | 返回错误，等待 orchestrator 决策 |
| 执行超时（>300s） | 返回超时状态，建议重试或终止 |
| 沙箱崩溃 | 返回崩溃日志，等待人工决策 |
| Tool 调用失败 | 记录失败原因，继续采集其他数据 |

**超时状态输出：**

```json
{
  "execution_result": {
    "status": "timeout",
    "timeout_seconds": 300,
    "partial_trace": { "..." },
    "error_message": "目标员工执行超时，建议：重试/跳过/终止"
  }
}
```

---

## Mock 模式

当 `mock_mode: true` 时，跳过沙箱创建，直接返回模拟执行结果：

```json
{
  "execution_result": {
    "status": "mock",
    "mock_data": {
      "logs": [
        { "type": "thought", "content": "模拟思考内容..." },
        { "type": "tool_call", "tool_name": "query_order", "success": true },
        { "type": "message", "role": "assistant", "content": "模拟回复..." }
      ],
      "summary": {
        "total_tool_calls": 2,
        "success_rate": 0.8
      }
    }
  }
}
```

---

## 执行约束

1. **必须**在注入测试输入后等待目标员工执行完成
2. **必须**捕获完整的执行轨迹，包括所有工具调用
3. **必须**分析语气/态度（如果支持）
4. **必须**标注缺失的工具调用，并标记严重程度
5. **禁止**跳过执行过程采集直接返回空结果
6. **禁止**在执行超时时自动终止，应返回状态等待决策