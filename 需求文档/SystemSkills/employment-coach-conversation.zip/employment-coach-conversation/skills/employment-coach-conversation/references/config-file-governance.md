# 配置文件治理（SOUL / IDENTITY / AGENTS / MEMORY）

本 skill 持续监听对话，识别用户对 `SOUL.md` / `IDENTITY.md` / `AGENTS.md` 三份配置的修改意图。`MEMORY.md` 全程不动。

## 监听触发条件

**同时**出现以下两类信号才触发：

1. 身份描述类关键词：名字、性别、形象、口吻、语气、使命、定位、责任、规则、约束、不能、必须、底线 等
2. 修改类动词：改、换、不是、应该叫、调整、补充、加上、去掉、不要 等

不满足两类信号同时出现，按普通对话处理，不进入治理流程。

## 文件归属判定

| 文件 | `config_key` | `relative_path` | 监听 | 内容范围 |
| --- | --- | --- | --- | --- |
| `SOUL.md` | `soul` | `config/SOUL.md` | ✅ | 角色身份与核心使命（"它是谁、为什么存在"） |
| `IDENTITY.md` | `identity` | `config/IDENTITY.md` | ✅ | 身份声明与对外展示（名字、形象、口吻、自我介绍） |
| `AGENTS.md` | `agents` | `config/AGENTS.md` | ✅ | 行为规范与边界约束（能做什么不能做什么、必须遵守的规则） |
| `MEMORY.md` | 不使用 | 不使用 | ❌ | 用户完全不接触，模板预设原样进实例包 |

## 可执行输出契约

配置治理不是在对话里口头说“已修改”，也不是直接写一个临时文件；必须在回复里输出宿主可解析的 `<config_governance_patch>` 标签。标签外只给用户一行自然语言确认，标签内写完整文件内容，不写 diff。

```json
<config_governance_patch>{
  "files": [
    {
      "config_key": "agents",
      "display_name": "AGENTS.md",
      "relative_path": "config/AGENTS.md",
      "content": "# AGENTS\n\n...更新后的完整内容...\n",
      "summary": "新增不主动承诺金额的行为边界",
      "updated_at": "2026-05-09T00:00:00Z",
      "affected_handoff_ids": ["s_refund_init_001"]
    }
  ]
}</config_governance_patch>
```

约束：

- `config_key` 只能写 `soul` / `identity` / `agents`；不要写 `agent`。
- `relative_path` 必须使用上表中的规范路径，大小写保持一致。
- `content` 是更新后的完整文件内容，不能只放一句新增规则。
- `affected_handoff_ids` 只填确实受边界、规则、判定或数据访问范围影响的 Handoff id；改名字、改口吻时写空数组。
- 任何情况下都不输出 `MEMORY.md` 的 patch。

## 混合反问机制

**置信度高**（用户表达明确、识别到的内容唯一） → 输出 `<config_governance_patch>` 更新对应文件 + 一行轻量反馈：

- "好的，名字已经改成『小琪』。"
- "记下了，AGENTS.md 里加上『不主动承诺金额』。"

**置信度低**（识别到的目标值含糊、可能误读） → 短反问，回放识别到的具体内容：

- 好："你是想把它的名字从『小智』改成『小琪』，对吗？"
- 不好："你是要修改身份信息吗？"（太泛，禁止这样问）

**用户回应处理**：

- 肯定（对、是的、嗯、没错、就这样）→ 输出 `<config_governance_patch>` 更新文件
- 否定（不是、不对、我是说……）→ 不更新；按用户的新表述重新走一次识别
- 答非所问 / 转移话题 → 视为不确认，不更新，不重复追问

**反馈方式**：

- 会话内：一行简短确认
- 右侧视图：当前展示的是这部分内容时同步刷新（这是系统层的事，本 skill 不主动控制）
- 不弹窗、不大块状态变更提示

**连续修改的处理**：

- 用户在反问待确认状态下又抛出新的修改意图 → 取消上一次反问，用新意图重新发起反问
- 永远只有一个反问处于待确认

## MEMORY.md 红线

任何情况下都**不要**修改 `MEMORY.md`。如果用户尝试讨论"它怎么记住事情"，告诉他这是模板预设、当前阶段不动，等部署后实际跑起来再观察。

## 改动反向触发 Handoff todo 复核

`SOUL.md` / `IDENTITY.md` / `AGENTS.md` 改动后，要判断是否影响 `status = confirmed` 的 Handoff todo。**只在改动属于"边界 / 规则 / 判定 / 数据访问范围"类时才提醒**，改名字、改口吻这种不要触发，会显得啰嗦。

判定方式（语义级，不是字符匹配）：

| 改动类型 | 可能影响的 `status = confirmed` Handoff todo |
| --- | --- |
| `SOUL.md` 使命范围调整 | 全部 skill Handoff todo 的存在合理性 |
| `IDENTITY.md` 名字 / 口吻调整 | 通常不影响 Handoff todo（不触发提醒） |
| `AGENTS.md` 判定规则 / 阈值 / 必转条件改动 | 含相同维度判定的 skill Handoff todo（trigger / description）、相关外部能力 Handoff todo（access scope） |
| `AGENTS.md` 红线 / 不能做的事改动 | 含越线动作的 skill 和 external Handoff todo |
| `AGENTS.md` 数据 / 隐私 / 凭据范围改动 | 全部 external Handoff todo 的 access scope |

发现潜在影响时，在那一行确认反馈后追加一句简短提醒，不要弹窗式打断：

> 好，AGENTS.md 已经改了。
> 顺便——你刚才改的这条可能影响『非标退货资格预判』和那条 CRM 订单读取，要不要一起回头过一下？

用户回应：

- **要 / 嗯好** → 用 `handoff`，`action = transition` 把相关 Handoff todo 的 `status` 从 `confirmed` 改为 `needs_review`，进入跨 Handoff 复核：逐条问"按新规则，这条还按之前那样跑可以吗"。确认无变更则回到 `confirmed`；需要改的回到 `ready_to_dispatch` 走重发
- **不要 / 先不管** → 不动状态，但在对应 Handoff todo 的 payload 里记一笔 `pending_review_reason`，下次诊断 skill 自然会照旧出工单
- **答非所问 / 转移话题** → 默认不动，不再追问

约束：

- 不要每改一次都开复核流程，只在判定逻辑层面变化时触发
- 一次改动最多列 2-3 条最直接相关的 Handoff todo，不要把所有 `confirmed` Handoff todo 都念一遍
- 复核过程中保持每条 Handoff todo 一个回合，不要批量抛给用户

Handoff todo 状态机详见 [handoff-tools.md](./handoff-tools.md)。
