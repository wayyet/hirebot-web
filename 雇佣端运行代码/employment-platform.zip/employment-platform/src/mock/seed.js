// ==== Mock Seed Data ====
// 对应文档 § 11 数据模型,精简到前端展示足够即可
// 所有数据均带 tenant_id,模拟多租户隔离

export const seedTemplates = [
  { id: 'tpl_kefu', name: '通用客服', icon: '💬', source: 'global', category: '客户服务',
    desc: '回答常见售前/售后问题、引导用户填表、记录工单',
    manifest: '耐心、专业的客服员工,优先理解用户诉求,精准回答',
    skills: ['查订单状态', '生成工单', '回答 FAQ', '情绪安抚'],
    scenes: ['售前咨询', '售后查询', '常规客诉'],
    version: 'v2.3', usedByDepts: 12, testCases: 14 },
  { id: 'tpl_aftersales', name: '售后专员', icon: '📞', source: 'global', category: '客户服务',
    desc: '处理退换货、维修申请、客诉记录',
    manifest: '熟悉退换货政策的售后人员',
    skills: ['退换货流程', '维修工单', '客诉记录', '物流查询'],
    scenes: ['退换货', '维修申请', '物流异常'],
    version: 'v1.8', usedByDepts: 8, testCases: 10 },
  { id: 'tpl_complaint', name: '投诉专员', icon: '⚠️', source: 'tenant', category: '客户服务',
    desc: '处理客户投诉,情绪安抚 + 升级路径',
    manifest: '耐心、专业、富有同理心的客户投诉处理专员。优先安抚情绪,准确记录诉求,按企业 SOP 升级紧急工单。',
    skills: ['识别情绪并应用 5 种安抚话术', '记录投诉到工单系统', '判断是否升级·自动 @主管', '查询客户历史记录'],
    scenes: ['普通投诉:产品质量/物流/服务态度类', '升级投诉:涉及金额>5000、客户情绪激烈', '不在范围:法务相关、监管投诉(直接转人工)'],
    version: 'v1.0', usedByDepts: 3, testCases: 12 },
  { id: 'tpl_data', name: '数据分析助手', icon: '📊', source: 'global', category: '数据分析',
    desc: 'SQL 编写、报表解读、趋势归因',
    manifest: '熟悉 SQL 与报表的数据分析师',
    skills: ['SQL 编写', '数据可视化', '趋势归因', '指标解读'],
    scenes: ['临时数据查询', '报表周报', '业务异动归因'],
    version: 'v3.1', usedByDepts: 21, testCases: 16 },
  { id: 'tpl_lead', name: '销售线索筛查', icon: '🎯', source: 'global', category: '市场销售',
    desc: '收集线索信息、初步定级、CRM 录入',
    manifest: '专业、礼貌的销售前置助手',
    skills: ['线索信息收集', '客户分级', 'CRM 录入', 'BANT 评估'],
    scenes: ['网站留资跟进', '展会线索', '冷启动外呼'],
    version: 'v2.0', usedByDepts: 9, testCases: 11 },
  { id: 'tpl_kb', name: '内部知识查询', icon: '📚', source: 'tenant', category: '内部支持',
    desc: '查询企业 wiki、HR 制度、IT 流程',
    manifest: '熟悉企业内部制度的咨询助手',
    skills: ['Wiki 全文检索', 'HR 制度查询', 'IT 流程查询', '答疑澄清'],
    scenes: ['HR 政策咨询', 'IT 报修指引', '内部流程查询'],
    version: 'v1.5', usedByDepts: 14, testCases: 13 }
]

export const seedInstances = [
  // 部门长 张明 管理的部门版
  { instance_id: 'inst_dept_4731', tenant_id: 't_demo',
    instance_type: 'department', status: 'live',
    based_on_template_id: 'tpl_kefu', from_instance_id: null,
    owner_user_id: 'u_zhangming', department_id: 'dept_kf',
    display_name: '客服小张', display_avatar_initial: '客张', avatar_color: 'blue',
    summary: '基于"通用客服"模板 · 客服部版',
    cloned_count: 24, avg_rating: 4.5, last_trained_at: '3 天前' },
  { instance_id: 'inst_dept_4732', tenant_id: 't_demo',
    instance_type: 'department', status: 'live',
    based_on_template_id: 'tpl_aftersales', from_instance_id: null,
    owner_user_id: 'u_zhangming', department_id: 'dept_kf',
    display_name: '售后小李', display_avatar_initial: '售李', avatar_color: 'purple',
    summary: '基于"售后专员"模板 · 客服部版',
    cloned_count: 15, avg_rating: 4.2, last_trained_at: '2 周前' },
  { instance_id: 'inst_dept_4831', tenant_id: 't_demo',
    instance_type: 'department', status: 'interning_ai',
    based_on_template_id: 'tpl_complaint', from_instance_id: null,
    owner_user_id: 'u_zhangming', department_id: 'dept_kf',
    display_name: '投诉处理小赵', display_avatar_initial: '投赵', avatar_color: 'amber',
    summary: '基于"投诉专员"模板 · 调教中', current_step: 4,
    cloned_count: 0, avg_rating: null, last_trained_at: '正在调教' },

  // 普通职员 王小芳 的分身
  { instance_id: 'inst_clone_8801', tenant_id: 't_demo',
    instance_type: 'personal_clone', status: 'live',
    based_on_template_id: 'tpl_kefu', from_instance_id: 'inst_dept_4731',
    owner_user_id: 'u_wangxiaofang', department_id: 'dept_kf',
    display_name: '我的客服小张', display_avatar_initial: '客小', avatar_color: 'blue',
    summary: '个人分身 · 来自客服小张部门版 · 复制于 12 天前',
    cloned_count: 0, avg_rating: 4.8, msg_count: 32, last_trained_at: null },
  { instance_id: 'inst_branch_8802', tenant_id: 't_demo',
    instance_type: 'private_branch', status: 'live',
    based_on_template_id: 'tpl_aftersales', from_instance_id: 'inst_clone_8810',
    owner_user_id: 'u_wangxiaofang', department_id: 'dept_kf',
    display_name: '售后小李(精简版)', display_avatar_initial: '售小', avatar_color: 'purple',
    summary: '私有分支 · 简化语气,加 VIP 名单',
    cloned_count: 0, avg_rating: 4.5, msg_count: 41, last_trained_at: '5 天前' },
  { instance_id: 'inst_clone_8803', tenant_id: 't_demo',
    instance_type: 'personal_clone', status: 'live',
    based_on_template_id: 'tpl_data', from_instance_id: null,
    owner_user_id: 'u_wangxiaofang', department_id: 'dept_kf',
    display_name: '我的数据小帮手', display_avatar_initial: '数', avatar_color: 'emerald',
    summary: '个人分身 · 来自数据分析助手 · 复制于 5 天前',
    cloned_count: 0, avg_rating: 4.4, msg_count: 14, last_trained_at: null }
]

export const seedFeedback = [
  { feedback_id: 'fb_1', instance_id: 'inst_dept_4731', from_user_id: 'u_wangxiaofang',
    from_user_name: '王小芳', feedback_type: 'training_issue', rating: 3,
    content: '投诉小张在处理高客单退款时总是超过 200 元上限就让用户等,但我们部门这周新政策是 500 以内可现批,建议更新 ontology。',
    status: 'pending', created_at: '1 小时前' },
  { feedback_id: 'fb_2', instance_id: 'inst_dept_4731', from_user_id: 'u_lishuai',
    from_user_name: '李伟', feedback_type: 'template_defect', rating: 4,
    content: '这个员工的回复有点太"标准化"了,跟我们部门的语气不太一样,我自己已经做了私有分支调整。但建议部门版也整体调整一下。',
    status: 'escalated', created_at: '5 小时前' },
  { feedback_id: 'fb_3', instance_id: 'inst_dept_4732', from_user_id: 'u_chenxiao',
    from_user_name: '陈晓', feedback_type: 'suggestion', rating: 4,
    content: '下午 3 点高峰期偶发回复延迟,但内容没问题。',
    status: 'resolved', created_at: '2 天前' }
]

// 调教对话脚本(用于演示六大步骤)
export const coachScripts = {
  scene_match: [
    { role: 'coach', text: '您好!我是雇佣教练,陪您把这个模板调教成本部门专属版。\n\n先聊聊场景:这次部门版主要应对哪类工作?例如以您过去一周的真实工作为例,描述 1-2 个典型场景。' }
  ],
  gap_dig: [
    { role: 'coach', text: '收到您描述的场景。模板覆盖了主要部分,但有两个差距点想跟您确认:\n(a) 模板默认对接通用工单系统,你们部门是接哪个系统?\n(b) 补偿权限上限,模板默认 200 元,你们呢?' }
  ],
  manifest: [
    { role: 'coach', text: '现在生成 manifest(人设)。基于您之前提到的"耐心+专业",我会写入:\n- 优先安抚情绪\n- 准确记录诉求\n- 升级时主动 @主管\n\n生成中...' }
  ],
  ontology: [
    { role: 'coach', text: 'ontology 是数字员工的"知识"。请上传相关文档(SOP、政策、FAQ),我会自动结构化。也可以直接告诉我关键信息。' }
  ],
  skill: [
    { role: 'coach', text: 'skill 工位会基于 ontology 生成具体能力清单。我已识别出需要的 4 个核心能力,正在生成 skill 调用代码...' }
  ],
  cli: [
    { role: 'coach', text: 'cli 工位配置外部对接。这个员工需要对接:工单系统(写入)、客户档案(读取)、内部 IM(@主管)。请确认对接凭证。' }
  ]
}

// AI 评估测试用例(模拟)
export const evaluationCases = [
  { id: 'case-001', name: '常规物流延迟咨询', score: 88, status: 'passed' },
  { id: 'case-002', name: '商品破损 + 情绪激烈', score: 91, status: 'passed' },
  { id: 'case-003', name: '错发型号要求换货', score: 79, status: 'passed' },
  { id: 'case-004', name: '补偿金额超权限', score: 68, status: 'borderline' },
  { id: 'case-005', name: '法律相关投诉', score: 85, status: 'passed' },
  { id: 'case-006', name: '多次投诉同一问题', score: 52, status: 'failed' },
  { id: 'case-007', name: '夹杂方言的口语描述', score: 81, status: 'passed' },
  { id: 'case-008', name: '工单系统超时', score: 76, status: 'passed' },
  { id: 'case-009', name: 'VIP 客户加急要求', score: 86, status: 'passed' },
  { id: 'case-010', name: '跨部门协作请求', score: 73, status: 'borderline' },
  { id: 'case-011', name: '系统故障期间咨询', score: 80, status: 'passed' },
  { id: 'case-012', name: '匿名用户骚扰类', score: 84, status: 'passed' }
]
