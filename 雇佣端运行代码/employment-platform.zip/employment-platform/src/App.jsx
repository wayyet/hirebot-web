import { Routes, Route, Navigate } from 'react-router-dom'
import { useApp } from './store.jsx'
import Shell from './components/Shell.jsx'

// Lead pages
import LeadDashboard from './pages/lead/Dashboard.jsx'
import TemplatePool from './pages/lead/TemplatePool.jsx'
import TemplateDetail from './pages/lead/TemplateDetail.jsx'
import HireWizard from './pages/lead/HireWizard.jsx'
import MyDept from './pages/lead/MyDept.jsx'
import FeedbackCenter from './pages/lead/FeedbackCenter.jsx'

// Staff pages
import StaffDashboard from './pages/staff/Dashboard.jsx'
import BrowseDept from './pages/staff/BrowseDept.jsx'
import CloneFlow from './pages/staff/CloneFlow.jsx'
import MyClones from './pages/staff/MyClones.jsx'
import FeishuChat from './pages/staff/FeishuChat.jsx'
import PrivateBranch from './pages/staff/PrivateBranch.jsx'

export default function App() {
  const { user } = useApp()

  return (
    <Shell>
      <Routes>
        {user.role === 'lead' ? (
          <>
            <Route path="/" element={<Navigate to="/lead/dashboard" replace />} />
            <Route path="/lead/dashboard" element={<LeadDashboard />} />
            <Route path="/lead/templates" element={<TemplatePool />} />
            <Route path="/lead/templates/:id" element={<TemplateDetail />} />
            <Route path="/lead/hire/:templateId" element={<HireWizard />} />
            <Route path="/lead/instances" element={<MyDept />} />
            <Route path="/lead/feedback" element={<FeedbackCenter />} />
            <Route path="*" element={<Navigate to="/lead/dashboard" replace />} />
          </>
        ) : (
          <>
            <Route path="/" element={<Navigate to="/staff/dashboard" replace />} />
            <Route path="/staff/dashboard" element={<StaffDashboard />} />
            <Route path="/staff/browse" element={<BrowseDept />} />
            <Route path="/staff/clone/:instanceId" element={<CloneFlow />} />
            <Route path="/staff/clones" element={<MyClones />} />
            <Route path="/staff/chat/:instanceId" element={<FeishuChat />} />
            <Route path="/staff/branch/:instanceId" element={<PrivateBranch />} />
            <Route path="*" element={<Navigate to="/staff/dashboard" replace />} />
          </>
        )}
      </Routes>
    </Shell>
  )
}
