import React, { createContext, useContext, useState, useCallback } from 'react'
import { seedInstances, seedTemplates, seedFeedback } from './mock/seed.js'

const Ctx = createContext(null)
export const useApp = () => useContext(Ctx)

export function AppProvider({ children }) {
  // 当前用户(演示用,默认部门长)
  const [user, setUser] = useState({
    id: 'u_zhangming',
    name: '张明',
    role: 'lead', // 'lead' | 'staff'
    department: '客服部',
    departmentId: 'dept_kf',
    tenantId: 't_demo'
  })
  const [templates] = useState(seedTemplates)
  const [instances, setInstances] = useState(seedInstances)
  const [feedbacks, setFeedbacks] = useState(seedFeedback)
  const [toast, setToast] = useState(null)

  const switchRole = useCallback((role) => {
    setUser(role === 'lead'
      ? { id: 'u_zhangming', name: '张明', role: 'lead', department: '客服部', departmentId: 'dept_kf', tenantId: 't_demo' }
      : { id: 'u_wangxiaofang', name: '王小芳', role: 'staff', department: '客服部', departmentId: 'dept_kf', tenantId: 't_demo' }
    )
  }, [])

  const addInstance = useCallback((inst) => {
    setInstances(prev => [...prev, inst])
  }, [])
  const updateInstance = useCallback((id, patch) => {
    setInstances(prev => prev.map(i => i.instance_id === id ? { ...i, ...patch } : i))
  }, [])
  const removeInstance = useCallback((id) => {
    setInstances(prev => prev.map(i => i.instance_id === id ? { ...i, status: 'retired' } : i))
  }, [])
  const addFeedback = useCallback((f) => setFeedbacks(prev => [f, ...prev]), [])

  const showToast = useCallback((msg) => {
    setToast(msg)
    setTimeout(() => setToast(null), 2400)
  }, [])

  return (
    <Ctx.Provider value={{
      user, switchRole, templates,
      instances, addInstance, updateInstance, removeInstance,
      feedbacks, addFeedback, showToast
    }}>
      {children}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-4 py-2 rounded-lg text-sm shadow-lg z-[100]">{toast}</div>
      )}
    </Ctx.Provider>
  )
}
