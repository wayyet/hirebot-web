import { NavLink, useNavigate, useLocation } from 'react-router-dom'
import { useApp } from '../store.jsx'
import { Avatar } from './UI.jsx'

const LEAD_NAV = [
  { to: '/lead/dashboard', label: '工作台', icon: '🏠' },
  { to: '/lead/templates', label: '模板池', icon: '📦' },
  { to: '/lead/instances', label: '我的部门版', icon: '👥' },
  { to: '/lead/feedback', label: '反馈聚合', icon: '📊' }
]
const STAFF_NAV = [
  { to: '/staff/dashboard', label: '工作台', icon: '🏠' },
  { to: '/staff/browse', label: '浏览部门版', icon: '🔍' },
  { to: '/staff/clones', label: '我的分身', icon: '👤' }
]

export default function Shell({ children }) {
  const { user, switchRole } = useApp()
  const navigate = useNavigate()
  const location = useLocation()
  const nav = user.role === 'lead' ? LEAD_NAV : STAFF_NAV
  const accentBg = user.role === 'lead' ? 'bg-blue-600' : 'bg-emerald-600'
  const accentText = user.role === 'lead' ? 'text-blue-600' : 'text-emerald-600'
  const accentBorder = user.role === 'lead' ? 'border-blue-600' : 'border-emerald-600'

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top bar */}
      <header className="bg-slate-900 text-white px-6 py-3 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 ${accentBg} rounded flex items-center justify-center text-sm font-bold`}>雇</div>
          <div>
            <div className="text-sm font-semibold">雇佣平台</div>
            <div className="text-xs text-slate-400">面向部门长 / 普通职员的 Employment Console</div>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-xs text-slate-400">演示用 · 一键切换角色:</div>
          <div className="flex bg-slate-800 rounded p-0.5">
            <button
              onClick={() => { switchRole('lead'); navigate('/lead/dashboard') }}
              className={`px-3 py-1 rounded text-xs ${user.role === 'lead' ? 'bg-blue-600' : 'text-slate-400'}`}>部门长 · 张明</button>
            <button
              onClick={() => { switchRole('staff'); navigate('/staff/dashboard') }}
              className={`px-3 py-1 rounded text-xs ${user.role === 'staff' ? 'bg-emerald-600' : 'text-slate-400'}`}>普通职员 · 王小芳</button>
          </div>
          <Avatar initial={user.name[0]} color={user.role === 'lead' ? 'blue' : 'emerald'} size="sm" />
        </div>
      </header>

      {/* Body */}
      <div className="flex flex-1">
        <aside className="w-56 bg-white border-r flex-shrink-0">
          <div className="p-4 border-b">
            <div className="text-xs text-slate-500">当前身份</div>
            <div className="text-sm font-medium mt-1">{user.name}</div>
            <div className="text-xs text-slate-500 mt-0.5">{user.department} · {user.role === 'lead' ? '部门长' : '普通职员'}</div>
          </div>
          <nav className="p-2 text-sm">
            {nav.map(item => (
              <NavLink key={item.to} to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3 py-2 rounded my-0.5 ${
                    isActive ? `bg-slate-100 ${accentText} font-medium border-l-2 ${accentBorder}` : 'text-slate-700 hover:bg-slate-50'
                  }`
                }>
                <span>{item.icon}</span>{item.label}
              </NavLink>
            ))}
          </nav>
          <div className="p-4 mt-4 text-xs text-slate-400 border-t">
            <div>v1.0 · MVP</div>
            <div className="mt-1">仅演示,不接真实后端</div>
          </div>
        </aside>

        <main className="flex-1 p-6 overflow-y-auto bg-slate-50" key={location.pathname}>
          {children}
        </main>
      </div>
    </div>
  )
}
