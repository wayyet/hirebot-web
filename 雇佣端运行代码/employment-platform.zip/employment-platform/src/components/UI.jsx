// ==== 复用 UI 组件 ====

const COLOR_MAP = {
  blue: 'bg-blue-100 text-blue-600',
  purple: 'bg-purple-100 text-purple-600',
  amber: 'bg-amber-100 text-amber-600',
  emerald: 'bg-emerald-100 text-emerald-600',
  rose: 'bg-rose-100 text-rose-600',
  indigo: 'bg-indigo-100 text-indigo-600',
  slate: 'bg-slate-100 text-slate-600'
}

export function Avatar({ initial, color = 'blue', size = 'md' }) {
  const sz = { sm: 'w-8 h-8 text-xs', md: 'w-10 h-10 text-sm', lg: 'w-14 h-14 text-lg', xl: 'w-20 h-20 text-2xl' }[size]
  return (
    <div className={`${sz} rounded-full flex items-center justify-center font-medium flex-shrink-0 ${COLOR_MAP[color] || COLOR_MAP.blue}`}>
      {initial}
    </div>
  )
}

export function Chip({ children, tone = 'slate' }) {
  const toneMap = {
    emerald: 'bg-emerald-100 text-emerald-700',
    blue: 'bg-blue-100 text-blue-700',
    amber: 'bg-amber-100 text-amber-700',
    rose: 'bg-rose-100 text-rose-700',
    purple: 'bg-purple-100 text-purple-700',
    slate: 'bg-slate-100 text-slate-600'
  }
  return <span className={`inline-block px-2 py-0.5 rounded text-xs ${toneMap[tone]}`}>{children}</span>
}

export const STATUS_TONE = {
  hired: 'slate',
  interning_ai: 'amber',
  interning_human: 'amber',
  live: 'emerald',
  failed: 'rose',
  retired: 'slate'
}
export const STATUS_LABEL = {
  hired: '已雇佣',
  interning_ai: 'AI 实习中',
  interning_human: '人工评估中',
  live: '已上岗',
  failed: '评估未通过',
  retired: '已退役'
}

// 六步骤进度条
export function Stepper({ current, accent = 'blue' }) {
  const steps = ['场景匹配', '差距挖掘', 'manifest', 'ontology', 'skill', 'cli 配置']
  const accentBg = accent === 'blue' ? 'bg-blue-600' : 'bg-emerald-500'
  return (
    <div>
      <div className="flex items-center gap-2 text-xs">
        {steps.map((_, i) => (
          <div key={i} className={`flex items-center ${i < steps.length - 1 ? 'flex-1' : ''}`}>
            <div className={`w-7 h-7 rounded-full flex items-center justify-center font-medium ${
              i < current ? 'bg-emerald-500 text-white' :
              i === current ? `${accentBg} text-white` :
              'bg-slate-200 text-slate-500'
            }`}>
              {i < current ? '✓' : i + 1}
            </div>
            {i < steps.length - 1 && <div className={`flex-1 mx-2 h-0.5 ${i < current ? 'bg-emerald-500' : 'bg-slate-200'}`} />}
          </div>
        ))}
      </div>
      <div className="flex justify-between text-xs mt-1.5">
        {steps.map((s, i) => (
          <span key={i} className={
            i < current ? 'text-emerald-600' :
            i === current ? `text-${accent}-600 font-medium` :
            'text-slate-500'
          }>{s}{i < current ? ' ✓' : ''}</span>
        ))}
      </div>
    </div>
  )
}

// 对话气泡
export function ChatBubble({ role, children }) {
  if (role === 'coach' || role === 'bot' || role === 'employee') {
    return (
      <div className="flex gap-3">
        <Avatar initial={role === 'coach' ? '🎓' : role === 'employee' ? '员' : '🤖'} size="sm" color="blue" />
        <div className="bg-slate-100 rounded-lg p-3 text-sm leading-relaxed flex-1 whitespace-pre-wrap">{children}</div>
      </div>
    )
  }
  return (
    <div className="flex gap-3 flex-row-reverse">
      <div className="w-8 h-8 bg-slate-300 rounded-full flex-shrink-0" />
      <div className="bg-blue-50 rounded-lg p-3 text-sm leading-relaxed flex-1 whitespace-pre-wrap">{children}</div>
    </div>
  )
}

// 卡片容器
export function Card({ children, className = '' }) {
  return <div className={`bg-white rounded-lg shadow-sm ${className}`}>{children}</div>
}

// 页面标题
export function PageHeader({ title, subtitle, right }) {
  return (
    <div className="border-b px-6 py-4 flex justify-between items-center">
      <div>
        <div className="font-medium">{title}</div>
        {subtitle && <div className="text-xs text-slate-500 mt-0.5">{subtitle}</div>}
      </div>
      {right}
    </div>
  )
}

// 空状态
export function Empty({ icon = '📭', title, desc, action }) {
  return (
    <div className="text-center py-12">
      <div className="text-4xl">{icon}</div>
      <div className="text-sm text-slate-500 mt-3">{title}</div>
      {desc && <div className="text-xs text-slate-400 mt-1">{desc}</div>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

// 主按钮(根据角色变色)
export function PrimaryBtn({ children, role = 'lead', className = '', ...props }) {
  const base = role === 'staff' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-blue-600 hover:bg-blue-700'
  return (
    <button {...props} className={`${base} text-white px-4 py-1.5 rounded text-sm font-medium disabled:bg-slate-300 disabled:cursor-not-allowed ${className}`}>
      {children}
    </button>
  )
}
