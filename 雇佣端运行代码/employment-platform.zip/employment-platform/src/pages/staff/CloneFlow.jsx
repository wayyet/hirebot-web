import { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useApp } from '../../store.jsx'
import { Card, Avatar } from '../../components/UI.jsx'
import * as api from '../../mock/api.js'

export default function CloneFlow() {
  const { instanceId } = useParams()
  const { user, instances, addInstance, showToast } = useApp()
  const navigate = useNavigate()
  const source = instances.find(i => i.instance_id === instanceId)

  const [step, setStep] = useState(1) // 1:确认 2:设身份 3:绑飞书 → 4:完成
  const [form, setForm] = useState({
    display_name: source ? `我的${source.display_name}` : '',
    description: source ? source.summary : '',
    avatar_initial: source?.display_avatar_initial || '?'
  })
  const [loading, setLoading] = useState(false)
  const [resultInstance, setResultInstance] = useState(null)

  if (!source) return <Card><div className="p-6 text-center text-slate-500">实例不存在</div></Card>

  async function handleClone() {
    if (!form.display_name.trim()) return showToast('请输入显示名')
    setLoading(true)
    setStep(3)
    const res = await api.clonePersonalInstance({
      from_instance_id: source.instance_id,
      display_name: form.display_name,
      display_avatar: form.avatar_initial,
      display_description: form.description
    })
    const newInst = {
      instance_id: res.data.instance_id,
      tenant_id: user.tenantId,
      instance_type: 'personal_clone',
      status: 'live',
      based_on_template_id: source.based_on_template_id,
      from_instance_id: source.instance_id,
      owner_user_id: user.id,
      department_id: user.departmentId,
      display_name: form.display_name,
      display_avatar_initial: form.avatar_initial,
      avatar_color: source.avatar_color,
      summary: form.description,
      bot_identity_id: res.data.bot_identity_id,
      feishu_bot_handle: res.data.feishu_bot_handle,
      cloned_count: 0, avg_rating: 5.0, msg_count: 0, last_trained_at: null
    }
    addInstance(newInst)
    setResultInstance(newInst)
    setLoading(false)
    setStep(4)
  }

  const accentEmerald = 'bg-emerald-600 hover:bg-emerald-700'

  return (
    <Card>
      <div className="border-b px-6 py-4">
        <div className="text-sm font-medium">复制"{source.display_name}"作为我的分身</div>
        <div className="flex items-center gap-3 mt-3 text-xs">
          {[
            { idx: 1, label: '确认复制' },
            { idx: 2, label: '设个人对外身份' },
            { idx: 3, label: '绑飞书,完成' }
          ].map((s, i, arr) => {
            const done = step > s.idx || step === 4
            const cur = step === s.idx
            return (
              <div key={s.idx} className={`flex items-center ${i < arr.length - 1 ? 'flex-1' : ''}`}>
                <div className={`w-7 h-7 rounded-full flex items-center justify-center font-medium ${
                  done ? 'bg-emerald-500 text-white' :
                  cur ? 'bg-emerald-600 text-white' :
                  'bg-slate-200 text-slate-500'
                }`}>{done ? '✓' : s.idx}</div>
                <span className={`ml-2 ${done || cur ? 'text-emerald-600 font-medium' : 'text-slate-500'}`}>{s.label}</span>
                {i < arr.length - 1 && <div className={`flex-1 mx-3 h-0.5 ${done ? 'bg-emerald-500' : 'bg-slate-200'}`} />}
              </div>
            )
          })}
        </div>
      </div>

      {/* Step 1: 确认 */}
      {step === 1 && (
        <div className="p-8 max-w-2xl mx-auto">
          <div className="bg-slate-50 rounded-lg p-6 flex items-start gap-4">
            <Avatar initial={source.display_avatar_initial} color={source.avatar_color} size="xl" />
            <div className="flex-1">
              <div className="text-lg font-semibold">{source.display_name}</div>
              <div className="text-sm text-slate-600 mt-2 leading-relaxed">{source.summary}</div>
              <div className="text-xs text-slate-500 mt-3">已被 {source.cloned_count} 人复制 · 平均 ★ {source.avg_rating}</div>
            </div>
          </div>
          <div className="bg-emerald-50 border border-emerald-200 rounded p-4 text-sm text-emerald-800 leading-relaxed mt-6">
            <div className="font-medium mb-2">🎉 一键复制 = 部门版的快照</div>
            您的分身将继承部门版的全部能力和评估结果,无需任何对话引导,跳过六大调教步骤。下一步只需为它取个名字、绑飞书。
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => navigate('/staff/browse')} className="flex-1 border rounded py-2 text-sm">取消</button>
            <button onClick={() => setStep(2)} className={`flex-1 ${accentEmerald} text-white rounded py-2 text-sm font-medium`}>
              确认复制 →
            </button>
          </div>
        </div>
      )}

      {/* Step 2: 设身份 */}
      {step === 2 && (
        <div className="p-8 grid grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="text-sm font-medium">在飞书里,这个分身叫什么?</div>
            <div>
              <label className="text-xs text-slate-500 block mb-1">显示名 <span className="text-rose-500">*</span></label>
              <input value={form.display_name} onChange={e => setForm({ ...form, display_name: e.target.value })}
                className="w-full border-2 border-emerald-400 rounded px-3 py-2.5 text-sm" />
              <div className="text-xs text-slate-500 mt-1">同名校验:✓ 你的其他分身没有这个名字</div>
            </div>
            <div>
              <label className="text-xs text-slate-500 block mb-1">头像缩写</label>
              <input value={form.avatar_initial} maxLength={2}
                onChange={e => setForm({ ...form, avatar_initial: e.target.value.slice(0, 2) })}
                className="w-32 border rounded px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="text-xs text-slate-500 block mb-1">简短描述(可选)</label>
              <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
                rows={2} className="w-full border rounded px-3 py-2 text-sm" />
            </div>
            <div className="bg-emerald-50 border border-emerald-200 rounded p-3 text-xs text-emerald-800 leading-relaxed">
              <div className="font-medium mb-1">🎉 不需要任何对话引导</div>
              分身复制 = 部门版的"快照",下一步绑定飞书后即可使用。
            </div>
          </div>
          <div>
            <div className="text-sm font-medium mb-3">飞书联系人预览</div>
            <div className="device-frame p-4 max-w-sm">
              <div className="bg-white rounded-lg border p-4 text-center">
                <Avatar initial={form.avatar_initial} color={source.avatar_color} size="xl" />
                <div className="text-base font-semibold mt-3">{form.display_name || '(未命名)'}</div>
                <div className="text-xs text-slate-500 mt-1">数字员工 · 仅你可见</div>
                <div className="text-xs text-slate-600 mt-3">{form.description}</div>
                <button className="bg-blue-600 text-white text-sm rounded w-full py-2 mt-4">发送消息</button>
              </div>
            </div>
            <div className="text-xs text-slate-500 mt-3">⚡ 复制完成后,这个 bot 只会出现在你的飞书联系人里。</div>
          </div>
        </div>
      )}
      {step === 2 && (
        <div className="border-t px-6 py-3 flex justify-between">
          <button onClick={() => setStep(1)} className="text-sm text-slate-500">‹ 返回</button>
          <button onClick={handleClone} className={`${accentEmerald} text-white px-6 py-1.5 rounded text-sm font-medium`}>下一步:绑定飞书 →</button>
        </div>
      )}

      {/* Step 3: 绑定飞书(loading 状态) */}
      {step === 3 && loading && (
        <div className="p-12 text-center max-w-md mx-auto">
          <div className="text-5xl pulse-soft mb-4">⏳</div>
          <div className="text-lg font-medium mb-2">正在为您启动数字员工...</div>
          <div className="text-sm text-slate-500 leading-relaxed">
            ① 创建 personal_clone 实例<br />
            ② 拉起运行时沙箱<br />
            ③ 注册个人飞书 bot 身份<br />
          </div>
          <div className="text-xs text-slate-400 mt-4">SLA:整个过程 P95 ≤ 30 秒</div>
        </div>
      )}

      {/* Step 4: 完成 */}
      {step === 4 && resultInstance && (
        <div className="p-12 text-center max-w-md mx-auto">
          <div className="w-24 h-24 bg-gradient-to-br from-emerald-400 to-blue-500 rounded-full flex items-center justify-center text-5xl mx-auto mb-6 pulse-soft">🎉</div>
          <h2 className="text-2xl font-semibold mb-2">{resultInstance.display_name}已就绪</h2>
          <div className="text-sm text-slate-500 mb-6">飞书 bot 已注册到你的联系人</div>
          <div className="bg-slate-50 rounded-lg p-4 text-left text-sm space-y-2">
            <div className="flex justify-between"><span className="text-slate-500">实例 ID</span><span className="font-mono text-xs">{resultInstance.instance_id}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">飞书 bot</span><span className="font-mono text-xs">{resultInstance.feishu_bot_handle}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">所有者</span><span>{user.name}(仅你可见)</span></div>
          </div>
          <div className="flex gap-2 mt-6">
            <button onClick={() => navigate('/staff/clones')} className="flex-1 border rounded py-2 text-sm">返回我的分身</button>
            <button onClick={() => navigate(`/staff/chat/${resultInstance.instance_id}`)} className={`flex-1 ${accentEmerald} text-white rounded py-2 text-sm font-medium`}>立即对话 →</button>
          </div>
        </div>
      )}
    </Card>
  )
}
