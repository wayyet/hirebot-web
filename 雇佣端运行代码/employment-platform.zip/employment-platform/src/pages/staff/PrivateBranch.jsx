import { useState, useRef, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useApp } from '../../store.jsx'
import { Card, ChatBubble, PrimaryBtn, Avatar, Stepper } from '../../components/UI.jsx'
import * as api from '../../mock/api.js'

export default function PrivateBranch() {
  const { instanceId } = useParams()
  const { user, instances, addInstance, showToast } = useApp()
  const navigate = useNavigate()
  const source = instances.find(i => i.instance_id === instanceId)

  const [phase, setPhase] = useState('coach') // coach → ai_eval → self_eval → live
  const [messages, setMessages] = useState([
    { role: 'coach', text: `你好 ${user?.name || ''}。私有分支只属于你自己,不影响部门版和其他人的分身。\n\n告诉我你想改的方向,我会判断需要重做哪些工位:\n① 改人设/语气 → manifest 工位\n② 加专属知识 → ontology 工位\n③ 增减能力 → skill 工位\n④ 换外部对接 → cli 工位` }
  ])
  const [input, setInput] = useState('')
  const [thinking, setThinking] = useState(false)
  const [redoSteps, setRedoSteps] = useState(['manifest', 'ontology']) // 默认假设要改这两个
  const [selfCases, setSelfCases] = useState([])
  const chatEnd = useRef(null)

  useEffect(() => {
    chatEnd.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  if (!source) return <Card><div className="p-6 text-center text-slate-500">实例不存在</div></Card>

  // 关键约束:私有分支不能基于私有分支(防止无限套娃)
  if (source.instance_type === 'private_branch') {
    return (
      <Card>
        <div className="p-12 text-center max-w-md mx-auto">
          <div className="text-5xl">🚫</div>
          <div className="text-base font-medium mt-3">不可对私有分支再创建分支</div>
          <div className="text-sm text-slate-500 mt-2 leading-relaxed">私有分支不能再次分支(防止无限套娃)。如需调整,请基于上游分身重新创建。</div>
          <button onClick={() => navigate('/staff/clones')} className="bg-emerald-600 text-white px-4 py-2 rounded text-sm mt-4">返回我的分身</button>
        </div>
      </Card>
    )
  }

  async function send() {
    if (!input.trim()) return
    setMessages(prev => [...prev, { role: 'user', text: input }])
    setInput('')
    setThinking(true)
    await api.postCoachMessage({ sandbox_id: 'sb_branch', step: 'manifest', message: input })
    setMessages(prev => [...prev, {
      role: 'coach',
      text: `收到。需要重做以下工位:\n${redoSteps.map(s => `• ${s} 工位`).join('\n')}\n\n其他工位沿用现有分身,不重做。是否继续?`
    }])
    setThinking(false)
  }

  function startEval() { setPhase('ai_eval'); setTimeout(() => setPhase('self_eval'), 2400) }

  function dropCase() {
    setSelfCases(prev => [...prev, {
      id: 'sc-' + (prev.length + 1),
      name: ['普通售后', 'VIP 加急', '边界场景', '复杂多轮'][prev.length % 4],
      rating: 4 + Math.random() * 0.8
    }])
  }

  function passSelfEval() {
    // 关键设计:私有分支评估通过后,不重新注册飞书 bot,而是切换路由(§ 6.3 § 9.4)
    const newBranch = {
      instance_id: 'inst_branch_' + Math.random().toString(36).slice(2, 6),
      tenant_id: user.tenantId,
      instance_type: 'private_branch',
      status: 'live',
      based_on_template_id: source.based_on_template_id,
      from_instance_id: source.instance_id,
      owner_user_id: user.id,
      department_id: user.departmentId,
      display_name: source.display_name + '(我的分支)',
      display_avatar_initial: source.display_avatar_initial,
      avatar_color: 'purple',
      summary: `私有分支 · 重做了 ${redoSteps.join('/')} 工位`,
      bot_identity_id: source.bot_identity_id,  // 复用原 bot
      feishu_bot_handle: source.feishu_bot_handle,  // 复用原 handle
      cloned_count: 0, avg_rating: 5.0, msg_count: 0, last_trained_at: '刚刚'
    }
    addInstance(newBranch)
    setPhase('live')
    showToast('飞书 bot 路由已切换到新分支')
  }

  return (
    <Card>
      <div className="border-b px-6 py-4">
        <div className="text-sm font-medium">为"{source.display_name}"创建私有分支</div>
        <div className="text-xs text-slate-500 mt-0.5">简化模式 · 只重做你想改的部分,其他工位继承现有分身</div>
      </div>

      {phase === 'coach' && (
        <>
          <div className="grid grid-cols-3" style={{ minHeight: 460 }}>
            <div className="col-span-2 border-r p-6 space-y-4 overflow-y-auto">
              {messages.map((m, i) => <ChatBubble key={i} role={m.role}>{m.text}</ChatBubble>)}
              {thinking && <ChatBubble role="coach">正在判断需要重做哪些工位...</ChatBubble>}
              <div ref={chatEnd} />
            </div>
            <div className="p-6 bg-slate-50 space-y-4 text-sm">
              <div>
                <div className="text-xs text-slate-500 mb-1">将重做的工位</div>
                <div className="space-y-1.5">
                  {redoSteps.map(s => (
                    <div key={s} className="bg-blue-100 border border-blue-300 rounded px-2.5 py-2 text-xs">
                      <div className="font-medium">{s}</div>
                      <div className="text-slate-600 mt-0.5">{s === 'manifest' ? '语气/人设调整' : '加专属知识'}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500 mb-1">将继承的工位</div>
                <div className="space-y-1.5">
                  {['skill', 'cli'].filter(s => !redoSteps.includes(s)).map(s => (
                    <div key={s} className="bg-white border rounded px-2.5 py-2 text-xs text-slate-500">
                      <div>{s}</div>
                      <div className="mt-0.5">沿用现有分身</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-amber-50 border border-amber-200 rounded p-3 text-xs text-amber-800 leading-relaxed">
                <div className="font-medium mb-1">🔒 隐私保护</div>
                你提供的私有材料存储在私有 ontology 中,只对你可见,部门长无法查看。
              </div>
            </div>
          </div>
          <div className="border-t px-6 py-3">
            <div className="flex gap-2 mb-3">
              <textarea value={input} onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
                rows={2} className="flex-1 border rounded px-3 py-2 text-sm" placeholder="比如:回复风格更简短一点..."></textarea>
              <button onClick={send} disabled={thinking} className="bg-blue-600 text-white px-4 rounded text-sm disabled:bg-slate-300">发送</button>
            </div>
            <div className="flex justify-between">
              <button onClick={() => navigate('/staff/clones')} className="text-sm text-slate-500">放弃私有分支</button>
              <PrimaryBtn role="staff" onClick={startEval}>开始重做选定工位 → AI 评估 →</PrimaryBtn>
            </div>
          </div>
        </>
      )}

      {phase === 'ai_eval' && (
        <div className="p-12 text-center max-w-md mx-auto">
          <div className="text-5xl pulse-soft mb-4">⏳</div>
          <div className="text-lg font-medium mb-2">AI 评估员正在工作...</div>
          <div className="text-sm text-slate-500 leading-relaxed">基于私有分支特点,使用更小的测试集(≥ 5 case)快速评估</div>
        </div>
      )}

      {phase === 'self_eval' && (
        <>
          <div className="border-b px-6 py-4 bg-emerald-50">
            <div className="text-sm font-medium">自评 · 由你判断分支是否符合预期</div>
            <div className="text-xs text-slate-500 mt-1">AI 评估已通过(78.6 分)。现在轮到你临场丢案例并打分,通过后才会切换飞书路由。</div>
          </div>
          <div className="grid grid-cols-3" style={{ minHeight: 420 }}>
            <div className="col-span-2 border-r p-6">
              <div className="device-frame p-4">
                <div className="border-b pb-2 mb-2 flex items-center gap-2">
                  <Avatar initial={source.display_avatar_initial} color="purple" size="sm" />
                  <div>
                    <div className="text-sm font-medium">{source.display_name} · 你的私有分支(评估中)</div>
                    <div className="text-xs text-slate-500">沙箱模式</div>
                  </div>
                </div>
                {selfCases.length === 0 ? (
                  <div className="text-center text-sm text-slate-500 py-8">点击右侧"+ 丢案例"开始</div>
                ) : (
                  <div className="space-y-2">
                    {selfCases.map((c, i) => (
                      <div key={c.id} className="bg-emerald-50 border border-emerald-200 rounded p-3 text-sm">
                        <div className="font-medium">案例 #{i + 1}: {c.name}</div>
                        <div className="text-xs text-emerald-700 mt-1">✓ 表现符合预期 · 评分 ★{c.rating.toFixed(1)}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="p-6 bg-slate-50 space-y-4 text-sm">
              <div>
                <div className="text-xs text-slate-500 mb-1">已丢案例</div>
                <div className="text-2xl font-semibold">{selfCases.length}<span className="text-sm text-slate-400 ml-1">/建议 ≥ 3</span></div>
              </div>
              <button onClick={dropCase} className="w-full border-2 border-dashed border-emerald-300 text-emerald-600 rounded py-2 text-sm hover:bg-emerald-50">+ 丢一个案例</button>
              <div className="text-xs text-slate-500 leading-relaxed pt-3 border-t">
                通过后:不重新注册飞书 bot,而是把现有 bot 的消息路由切换到新版本。在飞书的体验是"这个员工变聪明了"。
              </div>
            </div>
          </div>
          <div className="border-t px-6 py-3 flex justify-between">
            <button onClick={() => navigate('/staff/clones')} className="text-sm text-rose-600">⊗ 不通过 → 放弃</button>
            <PrimaryBtn role="staff" disabled={selfCases.length < 3} onClick={passSelfEval}>
              ✓ 通过 · 切换飞书路由 →
            </PrimaryBtn>
          </div>
        </>
      )}

      {phase === 'live' && (
        <div className="p-12 text-center max-w-md mx-auto">
          <div className="w-24 h-24 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center text-5xl mx-auto mb-6 pulse-soft">✨</div>
          <h2 className="text-2xl font-semibold mb-2">私有分支已上岗</h2>
          <div className="text-sm text-slate-500 mb-6 leading-relaxed">飞书 bot 路由已切换 · 在飞书私聊"{source.display_name}"将自动用新版本回复</div>
          <div className="flex gap-2">
            <button onClick={() => navigate('/staff/clones')} className="flex-1 border rounded py-2 text-sm">查看我的分身</button>
            <PrimaryBtn role="staff" className="!w-full !py-2" onClick={() => navigate(`/staff/chat/${source.instance_id}`)}>立即在飞书测试 →</PrimaryBtn>
          </div>
        </div>
      )}
    </Card>
  )
}
