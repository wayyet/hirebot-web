import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../../store.jsx'
import { Card, PageHeader, Chip } from '../../components/UI.jsx'

export default function TemplatePool() {
  const { templates } = useApp()
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const [source, setSource] = useState('all')
  const [category, setCategory] = useState('all')

  const filtered = templates.filter(t =>
    (q === '' || t.name.includes(q) || t.desc.includes(q)) &&
    (source === 'all' || t.source === source) &&
    (category === 'all' || t.category === category)
  )

  return (
    <Card>
      <PageHeader
        title="企业模板池"
        subtitle="来源:全局通用模板 + 本企业已发布(雇佣端不创建/派生模板)"
      />
      <div className="px-6 py-4 border-b flex gap-3">
        <input value={q} onChange={e => setQ(e.target.value)} className="flex-1 border rounded px-3 py-2 text-sm" placeholder="🔍 搜索:客服 / 销售 / 数据分析 ..." />
        <select value={source} onChange={e => setSource(e.target.value)} className="border rounded px-3 py-2 text-sm">
          <option value="all">全部来源</option>
          <option value="global">全局通用</option>
          <option value="tenant">本企业</option>
        </select>
        <select value={category} onChange={e => setCategory(e.target.value)} className="border rounded px-3 py-2 text-sm">
          <option value="all">全部场景</option>
          <option value="客户服务">客户服务</option>
          <option value="数据分析">数据分析</option>
          <option value="市场销售">市场销售</option>
          <option value="内部支持">内部支持</option>
        </select>
      </div>
      <div className="p-6 grid grid-cols-3 gap-4">
        {filtered.map(t => (
          <div key={t.id} className="border rounded-lg p-4 hover:shadow-md cursor-pointer transition"
            onClick={() => navigate(`/lead/templates/${t.id}`)}>
            <div className="flex justify-between items-start mb-2">
              <div className="w-10 h-10 bg-slate-100 rounded flex items-center justify-center text-xl">{t.icon}</div>
              <Chip tone={t.source === 'global' ? 'slate' : 'blue'}>
                {t.source === 'global' ? '全局通用' : '本企业'}
              </Chip>
            </div>
            <div className="font-medium text-sm">{t.name}</div>
            <div className="text-xs text-slate-500 mt-1 leading-relaxed line-clamp-2">{t.desc}</div>
            <div className="flex justify-between items-center mt-3 pt-3 border-t text-xs text-slate-500">
              <span>{t.version}</span>
              <span>已被 {t.usedByDepts} 个部门使用</span>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-3 text-center text-sm text-slate-500 py-12">没有匹配的模板</div>
        )}
      </div>
    </Card>
  )
}
