import { useParams, useNavigate } from 'react-router-dom'
import { useApp } from '../../store.jsx'
import { Card, Chip, PrimaryBtn } from '../../components/UI.jsx'

export default function TemplateDetail() {
  const { id } = useParams()
  const { templates } = useApp()
  const navigate = useNavigate()
  const t = templates.find(x => x.id === id)

  if (!t) return <Card><div className="p-6 text-center text-slate-500">模板不存在</div></Card>

  return (
    <Card>
      <div className="border-b px-6 py-4 flex items-center gap-3">
        <button onClick={() => navigate('/lead/templates')} className="text-sm text-slate-400">‹ 返回模板池</button>
      </div>
      <div className="p-6">
        <div className="flex items-start justify-between mb-6">
          <div className="flex gap-4">
            <div className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center text-3xl">{t.icon}</div>
            <div>
              <h2 className="text-xl font-semibold">{t.name}</h2>
              <div className="text-sm text-slate-500 mt-1">{t.version} · {t.source === 'global' ? '全局模板' : '本企业模板'}</div>
              <div className="flex gap-2 mt-2"><Chip tone="amber">{t.category}</Chip></div>
            </div>
          </div>
          <PrimaryBtn role="lead" className="!px-6 !py-2" onClick={() => navigate(`/lead/hire/${t.id}`)}>
            用此模板调教部门版 →
          </PrimaryBtn>
        </div>

        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2 space-y-5">
            <Section title="人设描述(manifest 摘要)">
              <div className="bg-slate-50 rounded p-3 text-sm text-slate-700 leading-relaxed">{t.manifest}</div>
            </Section>
            <Section title="能力清单(skill 摘要)">
              <div className="space-y-1.5">
                {t.skills.map((s, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <span className="text-emerald-600">✓</span>{s}
                  </div>
                ))}
              </div>
            </Section>
            <Section title="覆盖场景">
              <ul className="text-sm text-slate-600 leading-relaxed list-disc pl-5 space-y-1">
                {t.scenes.map((s, i) => <li key={i}>{s}</li>)}
              </ul>
            </Section>
          </div>
          <div className="space-y-3">
            <SideStat label="使用情况" value={`${t.usedByDepts} 个部门已基于此模板调教`} />
            <SideStat label="自带测试集" value={`${t.testCases} 个用例 · 覆盖主要场景`} />
            <div className="bg-amber-50 border border-amber-200 rounded p-3 text-xs text-amber-800 leading-relaxed">
              <div className="font-medium mb-1">📌 权限说明</div>
              您可以查看人设/能力描述/覆盖场景,但不可见模板源代码(五件套源)。雇佣端不支持派生模板——如需修改,请向"模板生产团队"反馈。
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}

function Section({ title, children }) {
  return (
    <div>
      <div className="text-sm font-medium mb-2">{title}</div>
      {children}
    </div>
  )
}
function SideStat({ label, value }) {
  return (
    <div className="bg-slate-50 rounded p-4">
      <div className="text-xs text-slate-500 mb-1">{label}</div>
      <div className="text-sm">{value}</div>
    </div>
  )
}
