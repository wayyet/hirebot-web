import { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useApp } from '../../store.jsx'
import { Card, Stepper, ChatBubble, PrimaryBtn, Avatar } from '../../components/UI.jsx'
import { coachScripts, evaluationCases } from '../../mock/seed.js'
import * as api from '../../mock/api.js'

const COACH_STEPS = ['scene_match', 'gap_dig', 'manifest', 'ontology', 'skill', 'cli']

export default function HireWizard() {
  const { templateId } = useParams()
  const { templates, user, addInstance, showToast } = useApp()
  const navigate = useNavigate()
  const tpl = templates.find(t => t.id === templateId)

  // 主阶段:coach → ai_eval → human_eval → review → bind_im → launched
  const [phase, setPhase] = useState('coach')
  const [coachStep, setCoachStep] = useState(0) // 0..5
  const [messages, setMessages] = useState(coachScripts.scene_match)
  const [input, setInput] = useState('')
  const [sandboxId] = useState('sb_' + Math.random().toString(36).slice(2, 8))
  const [thinking, setThinking] = useState(false)
  const chatEnd = useRef(null)

  // 评估状态
  const [evalProgress, setEvalProgress] = useState(0)
  const [evalCases, setEvalCases] = useState(evaluationCases.map(c => ({ ...c, evaluated: false })))
  const [aiPassed, setAiPassed] = useState(null)

  // 人工评估
  const [humanCases, setHumanCases] = useState([])

  // IM 绑定
  const [bindingForm, setBindingForm] = useState({
    display_name: tpl ? tpl.name : '',
    description: tpl ? tpl.desc : '',
    avatar_initial: tpl ? tpl.name.slice(0, 1) : ''
  })
  const [launchedInstance, setLaunchedInstance] = useState(null)

  useEffect(() => {
    chatEnd.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // ============ 调教对话 ============
  async function send() {
    if (!input.trim()) return
    setMessages(prev => [...prev, { role: 'user', text: input }])
    setInput('')
    setThinking(true)
    const stepKey = COACH_STEPS[coachStep]
    const res = await api.postCoachMessage({ sandbox_id: sandboxId, step: stepKey, message: input })
    setMessages(prev => [...prev, { role: 'coach', text: res.data.reply }])
    setThinking(false)
  }
  function nextStep() {
    if (coachStep === COACH_STEPS.length - 1) {
      // 进入 AI 评估
      setPhase('ai_eval')
      runAiEval()
    } else {
      const next = coachStep + 1
      setCoachStep(next)
      const nextScript = coachScripts[COACH_STEPS[next]]
      setMessages(prev => [...prev, ...nextScript])
    }
  }

  // ============ AI 评估 ============
  async function runAiEval() {
    setEvalProgress(0)
    const total = evalCases.length
    for (let i = 0; i < total; i++) {
      await new Promise(r => setTimeout(r, 400))
      setEvalCases(prev => prev.map((c, idx) => idx === i ? { ...c, evaluated: true } : c))
      setEvalProgress(Math.round(((i + 1) / total) * 100))
    }
    // 计算总分
    const total_score = evalCases.reduce((a, b) => a + b.score, 0) / evalCases.length
    const passed = total_score >= 75 && !evalCases.some(c => c.score < 60)
    setAiPassed(passed)
    setTimeout(() => setPhase(passed ? 'human_eval' : 'review'), 600)
  }

  // ============ 人工评估 ============
  function dropCase() {
    const newCase = { id: `hc-${humanCases.length + 1}`, name: ['真实物流投诉', 'VIP 加急', '边界情况测试', '复杂多轮对话'][humanCases.length % 4], rating: 4 + Math.random() * 0.8 }
    setHumanCases(prev => [...prev, newCase])
  }

  // ============ Review 失败回退 ============
  function reviewBackTo(stepIdx) {
    setCoachStep(stepIdx)
    const stepKey = COACH_STEPS[stepIdx]
    setMessages(prev => [...prev, { role: 'coach', text: `好的,从「${['场景匹配', '差距挖掘', 'manifest', 'ontology', 'skill', 'cli 配置'][stepIdx]}」工位重做。${coachScripts[stepKey]?.[0]?.text || ''}` }])
    setPhase('coach')
  }

  // ============ IM 绑定 + 上岗 ============
  async function confirmBind() {
    if (!bindingForm.display_name) return showToast('显示名必填')
    const unique = await api.checkDisplayNameUnique({ owner_user_id: user.id, display_name: bindingForm.display_name })
    if (!unique.data.unique) return showToast('该显示名已被占用')
    const reg = await api.registerBotIdentity({
      instance_id: 'pending', ...bindingForm
    })
    const inst = {
      instance_id: 'inst_dept_' + Math.random().toString(36).slice(2, 6),
      tenant_id: user.tenantId,
      instance_type: 'department',
      status: 'live',
      based_on_template_id: tpl.id,
      from_instance_id: null,
      owner_user_id: user.id,
      department_id: user.departmentId,
      display_name: bindingForm.display_name,
      display_avatar_initial: bindingForm.avatar_initial,
      avatar_color: 'emerald',
      summary: `基于"${tpl.name}"模板 · ${user.department}版`,
      bot_identity_id: reg.data.bot_identity_id,
      feishu_bot_handle: reg.data.feishu_bot_handle,
      cloned_count: 0, avg_rating: null, last_trained_at: '刚刚'
    }
    addInstance(inst)
    setLaunchedInstance(inst)
    setPhase('launched')
    showToast('上岗成功!')
  }

  if (!tpl) return <Card><div className="p-6 text-center text-slate-500">模板不存在</div></Card>

  // ============ 渲染 ============
  return (
    <Card>
      <div className="border-b px-6 py-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="text-sm font-medium">为{user.department}调教"{tpl.name}"</div>
            <div className="text-xs text-slate-500 mt-0.5">沙箱 {sandboxId} · 步骤 {phase === 'coach' ? `${coachStep + 1}/6` : phase}</div>
          </div>
          <button onClick={() => { if (confirm('确定放弃此次雇佣?所有调教草稿将丢失。')) navigate('/lead/templates') }}
            className="text-xs text-slate-500 hover:text-rose-500">放弃此次雇佣</button>
        </div>
        {phase === 'coach' && <Stepper current={coachStep} />}
      </div>

      {/* COACH 阶段 */}
      {phase === 'coach' && (
        <>
          <div className="grid grid-cols-3" style={{ minHeight: 480 }}>
            <div className="col-span-2 border-r p-6 space-y-4 overflow-y-auto">
              {messages.map((m, i) => <ChatBubble key={i} role={m.role}>{m.text}</ChatBubble>)}
              {thinking && <ChatBubble role="coach">正在思考...</ChatBubble>}
              <div ref={chatEnd} />
            </div>
            <div className="p-6 bg-slate-50 text-sm space-y-4">
              <div>
                <div className="text-xs text-slate-500 mb-1">当前工位</div>
                <div className="font-medium">{coachStep + 1}. {['场景匹配', '差距挖掘', 'manifest 工位', 'ontology 工位', 'skill 工位', 'cli 配置'][coachStep]}</div>
              </div>
              <div className="text-xs text-slate-600 leading-relaxed bg-white border rounded p-3">
                {[
                  '与教练对话,描述部门版应对的真实场景。沉淀的场景将成为后续步骤的输入,且自动作为评估测试用例。',
                  '教练根据场景与模板对比,挖掘差距并形成你部门的差异化清单。',
                  'AI 教练正在生成数字员工的人设描述,基于你之前提供的语气、风格、价值观偏好。',
                  '上传部门 SOP/政策/FAQ 等文档,AI 自动结构化为员工知识。',
                  '基于 ontology 生成具体能力清单,如查询、写入、判断、@通知。',
                  '配置外部对接(工单系统/CRM/IM),完成后即可进入评估。'
                ][coachStep]}
              </div>
            </div>
          </div>
          <div className="border-t px-6 py-3">
            <div className="flex gap-2 mb-3">
              <textarea value={input} onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
                rows={2} className="flex-1 border rounded px-3 py-2 text-sm" placeholder="回复教练..."></textarea>
              <button onClick={send} disabled={thinking} className="bg-blue-600 text-white px-4 rounded text-sm disabled:bg-slate-300">发送</button>
            </div>
            <div className="flex justify-between">
              <button className="text-sm text-slate-500" disabled={coachStep === 0}
                onClick={() => setCoachStep(s => Math.max(0, s - 1))}>‹ 返回上一步</button>
              <PrimaryBtn role="lead" onClick={nextStep}>
                {coachStep === COACH_STEPS.length - 1 ? '完成调教 · 进入 AI 评估 →' : `下一步:${['差距挖掘', 'manifest', 'ontology', 'skill', 'cli 配置', ''][coachStep]} →`}
              </PrimaryBtn>
            </div>
          </div>
        </>
      )}

      {/* AI 评估阶段 */}
      {phase === 'ai_eval' && (
        <div className="grid grid-cols-2" style={{ minHeight: 500 }}>
          <div className="border-r p-6 overflow-y-auto">
            <div className="text-sm font-medium mb-3">测试用例进度({evalProgress}%)</div>
            <div className="space-y-1.5 text-xs">
              {evalCases.map(c => (
                <div key={c.id} className={`border rounded p-2.5 flex justify-between items-center ${!c.evaluated ? 'text-slate-400' : ''}`}>
                  <span>{c.id}: {c.name}</span>
                  {c.evaluated ? (
                    <Tag tone={c.status === 'passed' ? 'emerald' : c.status === 'borderline' ? 'amber' : 'rose'}>
                      {c.status === 'passed' ? '通过' : c.status === 'borderline' ? '边界' : '未通过'} · {c.score}
                    </Tag>
                  ) : (
                    <span className="text-xs">{evalProgress > 0 && c.id === evalCases[Math.floor(evalProgress / 8.34)]?.id ? '⏳ 评估中' : '排队'}</span>
                  )}
                </div>
              ))}
            </div>
          </div>
          <div className="p-6">
            <div className="text-sm font-medium mb-3">实时评分</div>
            <div className="bg-slate-50 rounded p-4 mb-4 grid grid-cols-2 gap-3 text-xs">
              <div>
                <div className="text-slate-500">总分(暂)</div>
                <div className="text-2xl font-semibold mt-1">
                  {(evalCases.filter(c => c.evaluated).reduce((a, b) => a + b.score, 0) / Math.max(evalCases.filter(c => c.evaluated).length, 1)).toFixed(1)}
                </div>
              </div>
              <div>
                <div className="text-slate-500">通过阈值</div>
                <div className="text-2xl font-semibold mt-1">≥ 75</div>
              </div>
            </div>
            {aiPassed === null ? (
              <div className="text-center text-sm text-slate-500 py-8">
                <div className="text-3xl pulse-soft">⏳</div>
                <div className="mt-2">AI 评估员正在工作...</div>
              </div>
            ) : aiPassed ? (
              <div className="text-center bg-emerald-50 border border-emerald-200 rounded p-4">
                <div className="text-3xl">✓</div>
                <div className="text-sm font-medium mt-2 text-emerald-800">AI 评估通过</div>
                <div className="text-xs text-emerald-600 mt-1">即将进入人工评估</div>
              </div>
            ) : (
              <div className="text-center bg-rose-50 border border-rose-200 rounded p-4">
                <div className="text-3xl">✗</div>
                <div className="text-sm font-medium mt-2 text-rose-800">AI 评估未通过</div>
                <div className="text-xs text-rose-600 mt-1">即将进入失败 Review</div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 人工评估阶段 */}
      {phase === 'human_eval' && (
        <>
          <div className="grid grid-cols-3" style={{ minHeight: 480 }}>
            <div className="col-span-2 border-r p-6">
              <div className="text-sm font-medium mb-3">人工评估 · 您是评估者</div>
              <div className="text-xs text-slate-500 mb-4">AI 评估已通过(81.4 分)。现在轮到您临场丢真实案例,验证数字员工在您部门的实际表现。</div>
              <div className="device-frame p-4 mb-4">
                <div className="border-b pb-2 mb-2 flex items-center gap-2">
                  <Avatar initial={tpl.icon} color="amber" size="sm" />
                  <div>
                    <div className="text-sm font-medium">{tpl.name}(候选版)</div>
                    <div className="text-xs text-slate-500">沙箱模式 · 仅评估期可见</div>
                  </div>
                </div>
                {humanCases.length === 0 ? (
                  <div className="text-center text-sm text-slate-500 py-8">点击右侧"+ 丢一个真实案例"开始</div>
                ) : (
                  <div className="space-y-2">
                    {humanCases.map((c, i) => (
                      <div key={c.id} className="bg-slate-50 border rounded p-3 text-sm">
                        <div className="font-medium">案例 #{i + 1}: {c.name}</div>
                        <div className="text-xs text-slate-500 mt-1">数字员工已应对 · 评分 ★{c.rating.toFixed(1)}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="p-6 bg-slate-50 space-y-4 text-sm">
              <div>
                <div className="text-xs text-slate-500 mb-1">已丢案例</div>
                <div className="text-2xl font-semibold">{humanCases.length}<span className="text-sm text-slate-400 ml-1">/建议 ≥ 3 个</span></div>
              </div>
              <button onClick={dropCase} className="w-full border-2 border-dashed border-blue-300 text-blue-600 rounded py-2 text-sm hover:bg-blue-50">+ 丢一个真实案例</button>
              <div className="text-xs text-slate-500 leading-relaxed pt-3 border-t">所有案例自动沉淀回测试集,后续重新调教时复用。</div>
            </div>
          </div>
          <div className="border-t px-6 py-3 flex justify-between">
            <button onClick={() => setPhase('review')} className="text-sm text-rose-600">⊗ 评估不通过 → Review</button>
            <PrimaryBtn role="lead" disabled={humanCases.length < 3} onClick={() => setPhase('bind_im')}>
              ✓ 通过 · 进入 IM 绑定 →
            </PrimaryBtn>
          </div>
        </>
      )}

      {/* Review 失败 */}
      {phase === 'review' && (
        <>
          <div className="px-6 py-4 bg-rose-50 border-b">
            <div className="flex items-center gap-3">
              <div className="text-3xl">😞</div>
              <div>
                <div className="font-medium">本次评估未通过</div>
                <div className="text-xs text-slate-600 mt-1">AI 报告显示"边界守护"维度低于阈值,建议从差距挖掘或 ontology 重做</div>
              </div>
            </div>
          </div>
          <div className="p-6">
            <div className="text-sm font-medium mb-3">回退到哪个工位重做?</div>
            <div className="grid grid-cols-3 gap-3">
              {['场景匹配', '差距挖掘 ⚠ 推荐', 'manifest 工位', 'ontology 工位 ⚠ 推荐', 'skill 工位', 'cli 配置'].map((label, idx) => {
                const recommended = label.includes('推荐')
                return (
                  <button key={idx} onClick={() => reviewBackTo(idx)}
                    className={`border-2 rounded p-4 text-left ${recommended ? 'border-amber-400 bg-amber-50' : 'border-slate-200 hover:border-blue-300 hover:bg-blue-50'}`}>
                    <div className="font-medium text-sm">{label}</div>
                    <div className="text-xs text-slate-500 mt-1">
                      {['重新梳理场景', '补充边界场景', '调整人设/语气', '补充企业边界规则', '增减能力清单', '调整外部对接'][idx]}
                    </div>
                  </button>
                )
              })}
            </div>
            <div className="text-xs text-slate-500 mt-4">已上传源文件保留;选定工位后从该工位起重新生成产物。连续失败 3 次后系统会建议从场景匹配重新梳理。</div>
          </div>
        </>
      )}

      {/* IM 绑定 */}
      {phase === 'bind_im' && (
        <>
          <div className="border-b px-6 py-4 bg-emerald-50 flex items-center gap-3">
            <div className="text-2xl">🎉</div>
            <div>
              <div className="font-medium">评估通过!最后一步:配置部门版的飞书对外身份</div>
              <div className="text-xs text-slate-600 mt-1">这一步只决定职员们在飞书联系人里如何看到这个员工,不影响工作行为</div>
            </div>
          </div>
          <div className="p-6 grid grid-cols-2 gap-8">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium block mb-1">显示名 <span className="text-rose-500">*</span></label>
                <input value={bindingForm.display_name} onChange={e => setBindingForm({ ...bindingForm, display_name: e.target.value })}
                  className="w-full border rounded px-3 py-2 text-sm" placeholder="比如:投诉处理小赵" />
                <div className="text-xs text-slate-500 mt-1">飞书联系人列表中显示的名字。同一所有者下不可重名。</div>
              </div>
              <div>
                <label className="text-sm font-medium block mb-1">头像缩写</label>
                <input value={bindingForm.avatar_initial} onChange={e => setBindingForm({ ...bindingForm, avatar_initial: e.target.value.slice(0, 2) })}
                  maxLength={2} className="w-32 border rounded px-3 py-2 text-sm" />
              </div>
              <div>
                <label className="text-sm font-medium block mb-1">简短描述</label>
                <textarea value={bindingForm.description} onChange={e => setBindingForm({ ...bindingForm, description: e.target.value })}
                  rows={2} className="w-full border rounded px-3 py-2 text-sm" />
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded p-3 text-xs text-blue-800 leading-relaxed">
                <div className="font-medium mb-1">📋 关键区分</div>
                "对外身份"只影响飞书呈现,不影响数字员工的工作行为。修改对外身份不会触发再评估。
              </div>
            </div>
            <div>
              <div className="text-sm font-medium mb-3">飞书联系人详情页预览</div>
              <div className="device-frame p-4 max-w-sm">
                <div className="bg-white rounded-lg border p-4 text-center">
                  <Avatar initial={bindingForm.avatar_initial || '?'} color="amber" size="xl" />
                  <div className="text-base font-semibold mt-3">{bindingForm.display_name || '(未填写)'}</div>
                  <div className="text-xs text-slate-500 mt-1">{user.department} · 数字员工</div>
                  <div className="text-xs text-slate-600 mt-3 leading-relaxed">{bindingForm.description || '(未填写描述)'}</div>
                  <button className="bg-blue-600 text-white text-sm rounded w-full py-2 mt-4">发送消息</button>
                </div>
              </div>
            </div>
          </div>
          <div className="border-t px-6 py-3 flex justify-end">
            <button onClick={confirmBind} className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded text-sm font-medium">
              ✓ 确认配置 · 注册飞书 bot 身份 →
            </button>
          </div>
        </>
      )}

      {/* 上岗成功 */}
      {phase === 'launched' && launchedInstance && (
        <div className="p-12">
          <div className="max-w-md mx-auto text-center">
            <div className="w-24 h-24 bg-gradient-to-br from-emerald-400 to-blue-500 rounded-full flex items-center justify-center text-5xl mx-auto mb-6 pulse-soft">🚀</div>
            <h2 className="text-2xl font-semibold mb-2">{launchedInstance.display_name} 已上岗</h2>
            <div className="text-sm text-slate-500 mb-6">运行时沙箱启动 · 飞书 bot 身份已注册 · 状态切换为 live</div>
            <div className="bg-slate-50 rounded-lg p-4 text-left text-sm space-y-2">
              <Row k="实例 ID" v={launchedInstance.instance_id} />
              <Row k="飞书 bot handle" v={launchedInstance.feishu_bot_handle} />
              <Row k="沙箱模式" v="消息唤醒" />
              <Row k="部门可见性" v={`${user.department} 全员可复制`} />
            </div>
            <div className="flex gap-2 mt-6">
              <button onClick={() => navigate('/lead/instances')} className="flex-1 border rounded py-2 text-sm">查看部门版列表</button>
              <PrimaryBtn role="lead" className="!w-full !py-2" onClick={() => navigate('/lead/dashboard')}>返回工作台</PrimaryBtn>
            </div>
          </div>
        </div>
      )}
    </Card>
  )
}

function Tag({ tone, children }) {
  const toneMap = { emerald: 'bg-emerald-100 text-emerald-700', amber: 'bg-amber-100 text-amber-700', rose: 'bg-rose-100 text-rose-700' }
  return <span className={`px-2 py-0.5 rounded text-xs ${toneMap[tone]}`}>{children}</span>
}
function Row({ k, v }) {
  return <div className="flex justify-between"><span className="text-slate-500">{k}</span><span className="font-mono text-xs">{v}</span></div>
}
